################################################################################
# POSITION CLASSIFICATION HELPER SCRIPT
# Use this to derive df4_positions from your X-scan and validation data
################################################################################

library(tidyverse)

################################################################################
# FUNCTION 1: Derive HLA-Critical Positions from X-Scan
################################################################################

identify_hla_critical_positions <- function(xscan_df, 
                                            method = "sd",
                                            threshold_percentile = 0.75) {
  #'
  #' Identifies HLA-critical positions from X-scan data
  #' 
  #' @param xscan_df Data frame with columns: position, mutant_aa, hla_affinity_pred
  #' @param method "sd", "range", "cv", or "disruption"
  #' @param threshold_percentile Percentile for classification (default 0.75 = top 25%)
  #' @return Data frame with position and hla_critical flag
  #'
  
  position_analysis <- xscan_df %>%
    group_by(position) %>%
    summarise(
      # Method 1: Standard deviation (variability)
      sd_affinity = sd(hla_affinity_pred, na.rm = TRUE),
      
      # Method 2: Range (max - min)
      range_affinity = max(hla_affinity_pred, na.rm = TRUE) - 
                      min(hla_affinity_pred, na.rm = TRUE),
      
      # Method 3: Coefficient of variation
      cv_affinity = sd(hla_affinity_pred, na.rm = TRUE) / 
                   mean(hla_affinity_pred, na.rm = TRUE),
      
      # Method 4: Percentage of disruptive mutations (loss of binding)
      mean_affinity = mean(hla_affinity_pred, na.rm = TRUE),
      n_disruptive = sum(hla_affinity_pred > mean_affinity * 1.5, na.rm = TRUE),
      pct_disruptive = n_disruptive / n() * 100,
      
      # Method 5: Number of tolerated mutations
      n_tolerated = sum(hla_affinity_pred < quantile(hla_affinity_pred, 0.25, na.rm = TRUE)),
      pct_tolerated = n_tolerated / n() * 100,
      
      .groups = 'drop'
    )
  
  # Select method for classification
  if(method == "sd") {
    cutoff <- quantile(position_analysis$sd_affinity, threshold_percentile, na.rm = TRUE)
    position_analysis <- position_analysis %>%
      mutate(hla_critical = sd_affinity > cutoff)
    cat("Using SD method. Cutoff:", cutoff, "\n")
    
  } else if(method == "range") {
    cutoff <- quantile(position_analysis$range_affinity, threshold_percentile, na.rm = TRUE)
    position_analysis <- position_analysis %>%
      mutate(hla_critical = range_affinity > cutoff)
    cat("Using Range method. Cutoff:", cutoff, "\n")
    
  } else if(method == "cv") {
    cutoff <- quantile(position_analysis$cv_affinity, threshold_percentile, na.rm = TRUE)
    position_analysis <- position_analysis %>%
      mutate(hla_critical = cv_affinity > cutoff)
    cat("Using CV method. Cutoff:", cutoff, "\n")
    
  } else if(method == "disruption") {
    cutoff <- quantile(position_analysis$pct_disruptive, threshold_percentile, na.rm = TRUE)
    position_analysis <- position_analysis %>%
      mutate(hla_critical = pct_disruptive > cutoff)
    cat("Using Disruption method. Cutoff:", cutoff, "\n")
  }
  
  # Summary
  cat("\nHLA-Critical Positions Summary:\n")
  cat("  Total positions:", nrow(position_analysis), "\n")
  cat("  HLA-critical:", sum(position_analysis$hla_critical), "\n")
  cat("  Flexible:", sum(!position_analysis$hla_critical), "\n\n")
  
  return(position_analysis)
}

################################################################################
# FUNCTION 2: Derive Antibody-Critical Positions from Validation Data
################################################################################

identify_antibody_critical_positions <- function(validated_df, 
                                                 target_sequence,
                                                 method = "direct") {
  #'
  #' Identifies antibody-critical positions from validation data
  #' 
  #' @param validated_df Data frame with antibody validation results
  #' @param target_sequence Target peptide sequence string
  #' @param method "direct" (from mutation data), "alignment" (from sequences), or "manual"
  #' @return Data frame with position and antibody_critical flag
  #'
  
  target_length <- nchar(target_sequence)
  
  if(method == "direct") {
    # Assumes validated_df has a "position" column with mutation info
    if(!"position" %in% names(validated_df)) {
      stop("Method 'direct' requires 'position' column in validated_df")
    }
    
    antibody_analysis <- validated_df %>%
      mutate(is_binder = antibody_binding == "binder") %>%
      group_by(position) %>%
      summarise(
        n_total = n(),
        n_binders = sum(is_binder),
        binding_rate = n_binders / n_total,
        mean_signal = mean(binding_signal, na.rm = TRUE),
        .groups = 'drop'
      ) %>%
      mutate(
        # Position is antibody-critical if mutations reduce binding
        antibody_critical = binding_rate < 0.5  # Adjustable threshold
      )
    
  } else if(method == "alignment") {
    # Infer critical positions by comparing binders vs non-binders
    
    # Separate binders and non-binders
    binders <- validated_df %>% filter(antibody_binding == "binder")
    non_binders <- validated_df %>% filter(antibody_binding == "non_binder")
    
    # For each position, calculate conservation in binders vs non-binders
    position_conservation <- tibble(position = 1:target_length) %>%
      rowwise() %>%
      mutate(
        target_aa = str_sub(target_sequence, position, position),
        
        # Conservation in binders
        binder_match = mean(str_sub(binders$sequence, position, position) == target_aa),
        
        # Conservation in non-binders  
        nonbinder_match = mean(str_sub(non_binders$sequence, position, position) == target_aa),
        
        # Difference (high = critical for binding)
        conservation_diff = binder_match - nonbinder_match,
        
        # Entropy in binders (low = conserved = critical)
        binder_aas = list(str_sub(binders$sequence, position, position)),
        binder_entropy = calculate_shannon_entropy(binder_aas[[1]])
      ) %>%
      ungroup() %>%
      mutate(
        # Position is antibody-critical if highly conserved in binders
        antibody_critical = conservation_diff > 0.3 | binder_entropy < 0.5
      )
    
    antibody_analysis <- position_conservation
    
  } else if(method == "manual") {
    # Manually specify based on known epitope
    cat("Please enter antibody-critical positions (comma-separated, e.g., 3,5,7):\n")
    cat("Or provide epitope mapping results\n\n")
    
    # Create template
    antibody_analysis <- tibble(
      position = 1:target_length,
      antibody_critical = FALSE  # Set to TRUE for known epitope positions
    )
    
    cat("Update the antibody_critical column manually or provide epitope positions\n")
    
  }
  
  # Summary
  cat("\nAntibody-Critical Positions Summary:\n")
  cat("  Total positions:", nrow(antibody_analysis), "\n")
  cat("  Antibody-critical:", sum(antibody_analysis$antibody_critical), "\n")
  cat("  Non-critical:", sum(!antibody_analysis$antibody_critical), "\n\n")
  
  return(antibody_analysis)
}

# Helper function for entropy calculation
calculate_shannon_entropy <- function(aa_vector) {
  if(length(aa_vector) == 0) return(0)
  
  freq_table <- table(aa_vector) / length(aa_vector)
  entropy <- -sum(freq_table * log2(freq_table + 1e-10))
  
  return(entropy)
}

################################################################################
# FUNCTION 3: Combine into Full Position Classification
################################################################################

create_position_classification <- function(target_sequence,
                                          xscan_df,
                                          validated_df = NULL,
                                          hla_method = "sd",
                                          ab_method = "manual",
                                          known_epitope_positions = NULL) {
  #'
  #' Creates complete position classification data frame
  #' 
  #' @param target_sequence Target peptide sequence string
  #' @param xscan_df X-scan data frame
  #' @param validated_df Antibody validation data frame (optional)
  #' @param hla_method Method for HLA-critical identification
  #' @param ab_method Method for antibody-critical identification
  #' @param known_epitope_positions Vector of known epitope positions (for manual method)
  #' @return Complete df4_positions data frame
  #'
  
  target_length <- nchar(target_sequence)
  
  cat("="*80, "\n")
  cat("CREATING POSITION CLASSIFICATION\n")
  cat("="*80, "\n\n")
  
  # Step 1: Identify HLA-critical positions
  cat("Step 1: Identifying HLA-critical positions...\n")
  hla_analysis <- identify_hla_critical_positions(xscan_df, method = hla_method)
  
  # Step 2: Identify antibody-critical positions
  cat("\nStep 2: Identifying antibody-critical positions...\n")
  
  if(ab_method == "manual" && !is.null(known_epitope_positions)) {
    # Use provided epitope positions
    ab_analysis <- tibble(
      position = 1:target_length,
      antibody_critical = position %in% known_epitope_positions
    )
    cat("Using manually specified epitope positions:", 
        paste(known_epitope_positions, collapse=", "), "\n")
    
  } else if(!is.null(validated_df)) {
    ab_analysis <- identify_antibody_critical_positions(
      validated_df, 
      target_sequence, 
      method = ab_method
    )
  } else {
    # Default: assume no antibody-critical positions known
    ab_analysis <- tibble(
      position = 1:target_length,
      antibody_critical = FALSE
    )
    cat("No antibody validation data provided. All positions marked as non-critical.\n")
    cat("Please update manually if you have epitope information.\n")
  }
  
  # Step 3: Combine analyses
  cat("\nStep 3: Combining HLA and antibody analyses...\n")
  
  df4_positions <- tibble(position = 1:target_length) %>%
    mutate(wt_aa = str_sub(target_sequence, position, position)) %>%
    left_join(
      hla_analysis %>% select(position, hla_critical, sd_affinity, mean_affinity),
      by = "position"
    ) %>%
    left_join(
      ab_analysis %>% select(position, antibody_critical),
      by = "position"
    ) %>%
    mutate(
      # Combined classification
      classification = case_when(
        hla_critical & antibody_critical ~ "Both Critical",
        hla_critical & !antibody_critical ~ "HLA Dominant",
        !hla_critical & antibody_critical ~ "Antibody Dominant",
        TRUE ~ "Flexible"
      )
    )
  
  # Step 4: Summary
  cat("\n", "="*80, "\n")
  cat("POSITION CLASSIFICATION SUMMARY\n")
  cat("="*80, "\n\n")
  
  cat("Target Sequence:", target_sequence, "\n")
  cat("Length:", target_length, "positions\n\n")
  
  cat("Classification Breakdown:\n")
  print(table(df4_positions$classification))
  cat("\n")
  
  cat("Positions by Type:\n")
  cat("  Both Critical:      ", paste(which(df4_positions$classification == "Both Critical"), collapse=", "), "\n")
  cat("  HLA Dominant:       ", paste(which(df4_positions$classification == "HLA Dominant"), collapse=", "), "\n")
  cat("  Antibody Dominant:  ", paste(which(df4_positions$classification == "Antibody Dominant"), collapse=", "), "\n")
  cat("  Flexible:           ", paste(which(df4_positions$classification == "Flexible"), collapse=", "), "\n")
  cat("\n")
  
  return(df4_positions)
}

################################################################################
# FUNCTION 4: Visualize Position Classification
################################################################################

visualize_position_classification <- function(df4_positions, output_file = NULL) {
  
  p <- ggplot(df4_positions, aes(x = position, y = 1)) +
    geom_tile(aes(fill = classification), color = "black", size = 1.5, height = 0.8) +
    geom_text(aes(label = wt_aa), size = 8, fontface = "bold") +
    scale_fill_manual(
      values = c(
        "Both Critical" = "#d73027",
        "HLA Dominant" = "#fc8d59",
        "Antibody Dominant" = "#91bfdb",
        "Flexible" = "#4575b4"
      ),
      name = "Position Type"
    ) +
    scale_x_continuous(breaks = df4_positions$position, expand = c(0.02, 0.02)) +
    scale_y_continuous(expand = c(0, 0)) +
    labs(
      title = "Functional Topology: Position Classification",
      subtitle = "Red = Critical for both | Orange = HLA-buried | Blue = Surface-exposed | Dark Blue = Flexible",
      x = "Peptide Position"
    ) +
    theme_minimal(base_size = 14) +
    theme(
      axis.text.y = element_blank(),
      axis.title.y = element_blank(),
      axis.ticks.y = element_blank(),
      panel.grid = element_blank(),
      legend.position = "bottom",
      plot.title = element_text(hjust = 0.5, face = "bold"),
      plot.subtitle = element_text(hjust = 0.5, size = 10)
    )
  
  if(!is.null(output_file)) {
    ggsave(output_file, p, width = 12, height = 4)
    cat("Plot saved to:", output_file, "\n")
  }
  
  return(p)
}

################################################################################
# USAGE EXAMPLES
################################################################################

# Example 1: Using X-scan data only with manual epitope specification
example_usage_1 <- function() {
  
  # Your target sequence
  target_seq <- "MLAGKSLVLL"
  
  # Load your X-scan data
  xscan_data <- read_csv("your_xscan_data.csv")
  
  # Known epitope positions from literature or prior experiments
  epitope_positions <- c(3, 5, 7)  # Replace with your epitope
  
  # Create classification
  positions_df <- create_position_classification(
    target_sequence = target_seq,
    xscan_df = xscan_data,
    hla_method = "sd",
    ab_method = "manual",
    known_epitope_positions = epitope_positions
  )
  
  # Visualize
  visualize_position_classification(positions_df, "position_classification.pdf")
  
  # Save
  write_csv(positions_df, "df4_positions.csv")
  
  return(positions_df)
}

# Example 2: Using both X-scan and validation data
example_usage_2 <- function() {
  
  target_seq <- "MLAGKSLVLL"
  
  # Load your data
  xscan_data <- read_csv("your_xscan_data.csv")
  validation_data <- read_csv("your_validation_data.csv")
  
  # Create classification using alignment method
  positions_df <- create_position_classification(
    target_sequence = target_seq,
    xscan_df = xscan_data,
    validated_df = validation_data,
    hla_method = "sd",
    ab_method = "alignment"  # Infer from binder/non-binder comparison
  )
  
  # Visualize
  visualize_position_classification(positions_df, "position_classification.pdf")
  
  # Save
  write_csv(positions_df, "df4_positions.csv")
  
  return(positions_df)
}

# Example 3: Step-by-step manual approach
example_usage_3 <- function() {
  
  target_seq <- "MLAGKSLVLL"
  xscan_data <- read_csv("your_xscan_data.csv")
  
  # Step 1: Identify HLA-critical positions
  hla_critical <- identify_hla_critical_positions(
    xscan_data, 
    method = "sd",
    threshold_percentile = 0.75
  )
  
  # Step 2: Review and manually set antibody-critical positions
  # Based on your epitope mapping experiments
  df4_positions <- tibble(
    position = 1:nchar(target_seq),
    wt_aa = str_sub(target_seq, position, position)
  ) %>%
    left_join(hla_critical %>% select(position, hla_critical), by = "position") %>%
    mutate(
      # Manually specify based on your antibody epitope data
      antibody_critical = case_when(
        position %in% c(3, 5, 7) ~ TRUE,  # Your epitope positions
        TRUE ~ FALSE
      ),
      # Combined classification
      classification = case_when(
        hla_critical & antibody_critical ~ "Both Critical",
        hla_critical & !antibody_critical ~ "HLA Dominant",
        !hla_critical & antibody_critical ~ "Antibody Dominant",
        TRUE ~ "Flexible"
      )
    )
  
  # Visualize and save
  visualize_position_classification(df4_positions, "position_classification.pdf")
  write_csv(df4_positions, "df4_positions.csv")
  
  return(df4_positions)
}

################################################################################
# INTERACTIVE HELPER
################################################################################

create_positions_interactive <- function() {
  #'
  #' Interactive helper to create position classification
  #'
  
  cat("\n")
  cat("="*80, "\n")
  cat("INTERACTIVE POSITION CLASSIFICATION TOOL\n")
  cat("="*80, "\n\n")
  
  # Get target sequence
  cat("Enter your target peptide sequence:\n")
  target_seq <- readline("> ")
  target_length <- nchar(target_seq)
  cat("\nTarget sequence:", target_seq, "\n")
  cat("Length:", target_length, "positions\n\n")
  
  # Get X-scan file
  cat("Enter path to X-scan data file (CSV):\n")
  xscan_file <- readline("> ")
  xscan_data <- read_csv(xscan_file)
  cat("Loaded", nrow(xscan_data), "X-scan variants\n\n")
  
  # Choose HLA method
  cat("Choose HLA-critical identification method:\n")
  cat("  1. Standard Deviation (recommended)\n")
  cat("  2. Range\n")
  cat("  3. Coefficient of Variation\n")
  cat("  4. Disruption percentage\n")
  hla_method_choice <- as.integer(readline("> "))
  hla_methods <- c("sd", "range", "cv", "disruption")
  hla_method <- hla_methods[hla_method_choice]
  
  # Choose antibody method
  cat("\nHow do you want to specify antibody-critical positions?\n")
  cat("  1. Manual (I know the epitope positions)\n")
  cat("  2. From validation data (alignment method)\n")
  cat("  3. Skip (mark all as non-critical)\n")
  ab_choice <- as.integer(readline("> "))
  
  if(ab_choice == 1) {
    cat("\nEnter epitope positions (comma-separated, e.g., 3,5,7):\n")
    epitope_input <- readline("> ")
    epitope_positions <- as.integer(unlist(strsplit(epitope_input, ",")))
    
    positions_df <- create_position_classification(
      target_sequence = target_seq,
      xscan_df = xscan_data,
      hla_method = hla_method,
      ab_method = "manual",
      known_epitope_positions = epitope_positions
    )
    
  } else if(ab_choice == 2) {
    cat("\nEnter path to antibody validation data file (CSV):\n")
    validation_file <- readline("> ")
    validation_data <- read_csv(validation_file)
    
    positions_df <- create_position_classification(
      target_sequence = target_seq,
      xscan_df = xscan_data,
      validated_df = validation_data,
      hla_method = hla_method,
      ab_method = "alignment"
    )
    
  } else {
    positions_df <- create_position_classification(
      target_sequence = target_seq,
      xscan_df = xscan_data,
      hla_method = hla_method,
      ab_method = "manual",
      known_epitope_positions = NULL
    )
  }
  
  # Visualize
  cat("\nGenerating visualization...\n")
  visualize_position_classification(positions_df, "position_classification.pdf")
  
  # Save
  cat("Saving results...\n")
  write_csv(positions_df, "df4_positions.csv")
  
  cat("\n✓ Position classification complete!\n")
  cat("  - Classification table: df4_positions.csv\n")
  cat("  - Visualization: position_classification.pdf\n\n")
  
  return(positions_df)
}

################################################################################
# QUICK START
################################################################################

cat("\n")
cat("="*80, "\n")
cat("POSITION CLASSIFICATION HELPER\n")
cat("="*80, "\n\n")
cat("This script helps you create df4_positions from your data.\n\n")
cat("Available functions:\n")
cat("  - create_positions_interactive()  # Interactive guided setup\n")
cat("  - example_usage_1()                # X-scan + manual epitope\n")
cat("  - example_usage_2()                # X-scan + validation data\n")
cat("  - example_usage_3()                # Step-by-step manual\n\n")
cat("For full control, use individual functions:\n")
cat("  - identify_hla_critical_positions()\n")
cat("  - identify_antibody_critical_positions()\n")
cat("  - create_position_classification()\n")
cat("  - visualize_position_classification()\n\n")

################################################################################
# END OF SCRIPT
################################################################################
