################################################################################
# MINIMAL TEST EXAMPLE
# Run this to verify the workflow with synthetic data
################################################################################

library(tidyverse)
library(pheatmap)

# Set seed for reproducibility
set.seed(42)

################################################################################
# 1. CREATE SYNTHETIC TEST DATA
################################################################################

cat("Creating synthetic test data...\n")

# Target sequence (9-mer example)
target_seq <- "SLYNTVATL"  # Example HIV epitope
target_length <- nchar(target_seq)

# 1. Off-targets (n=1454)
df1_offtargets <- tibble(
  peptide_id = c("TARGET", paste0("OT_", 1:1453)),
  sequence = c(
    target_seq,
    replicate(1453, paste(sample(c("A","C","D","E","F","G","H","I","K","L",
                                   "M","N","P","Q","R","S","T","V","W","Y"), 
                                 target_length, replace=TRUE), collapse=""))
  ),
  hla_affinity_pred = c(
    5,  # Target has good affinity
    rnorm(1453, 50, 20)  # Off-targets vary
  ),
  is_target = c(TRUE, rep(FALSE, 1453))
)

# 2. X-scan (19 substitutions × 9 positions = 171)
amino_acids <- c("A","C","D","E","F","G","H","I","K","L",
                 "M","N","P","Q","R","S","T","V","W","Y")

df2_xscan <- expand_grid(
  position = 1:target_length,
  mutant_aa = amino_acids
) %>%
  mutate(
    variant_id = paste0("P", position, mutant_aa),
    # Simulate position-specific sensitivity
    # Positions 2 and 9 are HLA anchors (sensitive to mutation)
    hla_affinity_pred = case_when(
      position == 2 ~ rnorm(n(), 40, 25),  # High variability
      position == 9 ~ rnorm(n(), 35, 30),  # High variability
      position %in% c(4, 5, 6) ~ rnorm(n(), 10, 5),  # Surface-exposed (low impact)
      TRUE ~ rnorm(n(), 20, 10)
    )
  ) %>%
  # Clip to reasonable range
  mutate(hla_affinity_pred = pmax(0.1, pmin(100, hla_affinity_pred)))

# 3. Antibody validation (~400)
df3_validated <- tibble(
  peptide_id = paste0("VAL_", 1:400),
  sequence = replicate(400, paste(sample(c("A","C","D","E","F","G","H","I","K","L",
                                            "M","N","P","Q","R","S","T","V","W","Y"), 
                                          target_length, replace=TRUE), collapse="")),
  # Simulate: positions 4, 5, 6 are antibody epitope
  epitope_match = map_dbl(sequence, function(seq) {
    sum(str_sub(seq, 4:6, 4:6) == str_sub(target_seq, 4:6, 4:6)) / 3
  }),
  antibody_binding = ifelse(epitope_match > 0.6 & runif(400) > 0.3, "binder", "non_binder"),
  binding_signal = ifelse(antibody_binding == "binder", 
                         rnorm(400, 85, 10), 
                         rnorm(400, 15, 8))
)

# 4. Position classification
# Positions 2, 9 = HLA anchors (from X-scan variability)
# Positions 4, 5, 6 = antibody epitope (from validation)
df4_positions <- tibble(
  position = 1:target_length,
  wt_aa = str_sub(target_seq, position, position),
  hla_critical = position %in% c(2, 9),
  antibody_critical = position %in% c(4, 5, 6)
) %>%
  mutate(
    classification = case_when(
      hla_critical & antibody_critical ~ "Both Critical",
      hla_critical ~ "HLA Dominant",
      antibody_critical ~ "Antibody Dominant",
      TRUE ~ "Flexible"
    )
  )

cat("✓ Test data created\n")
cat("  - Target:", target_seq, "\n")
cat("  - Off-targets:", nrow(df1_offtargets), "\n")
cat("  - X-scan variants:", nrow(df2_xscan), "\n")
cat("  - Validated peptides:", nrow(df3_validated), "\n")
cat("  - Position classifications:", nrow(df4_positions), "\n\n")

################################################################################
# 2. ANALYSIS FUNCTIONS (simplified)
################################################################################

analyze_positions <- function(xscan_df, positions_df) {
  xscan_df %>%
    group_by(position) %>%
    summarise(
      mean_affinity = mean(hla_affinity_pred, na.rm=TRUE),
      sd_affinity = sd(hla_affinity_pred, na.rm=TRUE),
      .groups = 'drop'
    ) %>%
    left_join(positions_df, by = "position")
}

classify_offtargets <- function(offtarget_df, positions_df, target_seq) {
  
  hla_pos <- positions_df %>% filter(hla_critical) %>% pull(position)
  ab_pos <- positions_df %>% filter(antibody_critical) %>% pull(position)
  
  offtarget_df %>%
    rowwise() %>%
    mutate(
      match_hla = if(length(hla_pos) > 0) {
        sum(str_sub(sequence, hla_pos, hla_pos) == 
            str_sub(target_seq, hla_pos, hla_pos)) / length(hla_pos)
      } else { 0 },
      match_ab = if(length(ab_pos) > 0) {
        sum(str_sub(sequence, ab_pos, ab_pos) == 
            str_sub(target_seq, ab_pos, ab_pos)) / length(ab_pos)
      } else { 0 },
      risk = case_when(
        match_hla > 0.8 & match_ab > 0.8 & hla_affinity_pred < 50 ~ "High",
        match_hla > 0.5 | match_ab > 0.5 ~ "Medium",
        TRUE ~ "Low"
      )
    ) %>%
    ungroup()
}

################################################################################
# 3. RUN ANALYSIS
################################################################################

cat("Running analysis...\n")

position_summary <- analyze_positions(df2_xscan, df4_positions)
offtargets_classified <- classify_offtargets(df1_offtargets, df4_positions, target_seq)

cat("✓ Analysis complete\n\n")

################################################################################
# 4. RESULTS SUMMARY
################################################################################

cat("="*80, "\n")
cat("RESULTS SUMMARY\n")
cat("="*80, "\n\n")

cat("Position Classification:\n")
print(table(df4_positions$classification))
cat("\n")

cat("Position Details:\n")
print(df4_positions %>% select(position, wt_aa, classification))
cat("\n")

cat("Off-Target Risk Distribution:\n")
print(table(offtargets_classified$risk))
cat("\n")

cat("High-Risk Off-Targets (top 10):\n")
high_risk <- offtargets_classified %>%
  filter(risk == "High") %>%
  arrange(hla_affinity_pred) %>%
  head(10)
print(high_risk %>% select(peptide_id, sequence, hla_affinity_pred, match_hla, match_ab))
cat("\n")

################################################################################
# 5. CREATE VISUALIZATIONS
################################################################################

cat("Creating visualizations...\n")

# Create output directory
if(!dir.exists("test_output")) dir.create("test_output")

# Plot 1: Position topology map
p1 <- ggplot(df4_positions, aes(x = position, y = 1)) +
  geom_tile(aes(fill = classification), color = "black", size = 1.5) +
  geom_text(aes(label = wt_aa), size = 8, fontface = "bold") +
  scale_fill_manual(
    values = c(
      "Both Critical" = "#d73027",
      "HLA Dominant" = "#fc8d59", 
      "Antibody Dominant" = "#91bfdb",
      "Flexible" = "#4575b4"
    )
  ) +
  scale_x_continuous(breaks = 1:target_length) +
  labs(
    title = "Functional Topology Map (Test Data)",
    subtitle = paste("Target:", target_seq),
    x = "Position",
    fill = "Classification"
  ) +
  theme_minimal(base_size = 12) +
  theme(
    axis.text.y = element_blank(),
    axis.title.y = element_blank(),
    panel.grid = element_blank(),
    legend.position = "bottom"
  )

ggsave("test_output/topology_map.pdf", p1, width = 10, height = 3)
cat("  ✓ Topology map saved\n")

# Plot 2: X-scan heatmap
xscan_matrix <- df2_xscan %>%
  select(position, mutant_aa, hla_affinity_pred) %>%
  pivot_wider(names_from = position, values_from = hla_affinity_pred) %>%
  column_to_rownames("mutant_aa") %>%
  as.matrix()

annotation_col <- df4_positions %>%
  select(position, classification) %>%
  column_to_rownames("position")

pdf("test_output/xscan_heatmap.pdf", width = 8, height = 8)
pheatmap(
  xscan_matrix,
  cluster_rows = TRUE,
  cluster_cols = FALSE,
  annotation_col = annotation_col,
  annotation_colors = list(
    classification = c(
      "Both Critical" = "#d73027",
      "HLA Dominant" = "#fc8d59",
      "Antibody Dominant" = "#91bfdb",
      "Flexible" = "#4575b4"
    )
  ),
  color = colorRampPalette(c("blue", "white", "red"))(100),
  main = "X-Scan HLA Affinity Profile (Test Data)"
)
dev.off()
cat("  ✓ X-scan heatmap saved\n")

# Plot 3: Position sensitivity
p3 <- ggplot(position_summary, aes(x = position, y = mean_affinity)) +
  geom_line(size = 1) +
  geom_ribbon(aes(ymin = mean_affinity - sd_affinity,
                  ymax = mean_affinity + sd_affinity),
              alpha = 0.2) +
  geom_point(aes(fill = classification), size = 4, shape = 21, stroke = 1) +
  scale_fill_manual(
    values = c(
      "Both Critical" = "#d73027",
      "HLA Dominant" = "#fc8d59",
      "Antibody Dominant" = "#91bfdb",
      "Flexible" = "#4575b4"
    )
  ) +
  labs(
    title = "Position-Specific HLA Sensitivity (Test Data)",
    x = "Position",
    y = "Mean HLA Affinity",
    fill = "Classification"
  ) +
  theme_bw()

ggsave("test_output/position_sensitivity.pdf", p3, width = 10, height = 6)
cat("  ✓ Position sensitivity plot saved\n")

# Plot 4: Off-target risk scatter
p4 <- ggplot(offtargets_classified %>% filter(!is_target), 
             aes(x = match_hla, y = match_ab)) +
  geom_point(aes(color = risk, size = hla_affinity_pred), alpha = 0.6) +
  scale_color_manual(values = c("High" = "#d73027", "Medium" = "#fee090", "Low" = "#4575b4")) +
  scale_size_continuous(trans = "reverse", range = c(1, 4)) +
  labs(
    title = "Off-Target Dual Similarity Profile (Test Data)",
    x = "Match to HLA-Critical Positions",
    y = "Match to Antibody-Critical Positions",
    color = "Risk",
    size = "HLA Affinity"
  ) +
  theme_bw()

ggsave("test_output/offtarget_scatter.pdf", p4, width = 8, height = 6)
cat("  ✓ Off-target scatter plot saved\n")

# Plot 5: Risk distribution
p5 <- ggplot(offtargets_classified %>% filter(!is_target), 
             aes(x = risk, fill = risk)) +
  geom_bar() +
  geom_text(stat = 'count', aes(label = after_stat(count)), vjust = -0.5) +
  scale_fill_manual(values = c("High" = "#d73027", "Medium" = "#fee090", "Low" = "#4575b4")) +
  labs(
    title = "Off-Target Risk Distribution (Test Data)",
    x = "Risk Category",
    y = "Count"
  ) +
  theme_bw() +
  theme(legend.position = "none")

ggsave("test_output/risk_distribution.pdf", p5, width = 6, height = 5)
cat("  ✓ Risk distribution plot saved\n")

################################################################################
# 6. EXPORT DATA
################################################################################

cat("\nExporting data tables...\n")

write_csv(df4_positions, "test_output/position_classification.csv")
write_csv(offtargets_classified, "test_output/offtargets_classified.csv")
write_csv(position_summary, "test_output/position_summary.csv")

cat("  ✓ Data tables exported\n")

################################################################################
# 7. FINAL SUMMARY
################################################################################

cat("\n")
cat("="*80, "\n")
cat("TEST COMPLETE!\n")
cat("="*80, "\n\n")

cat("Output files created in test_output/ directory:\n")
cat("  Plots:\n")
cat("    - topology_map.pdf\n")
cat("    - xscan_heatmap.pdf\n")
cat("    - position_sensitivity.pdf\n")
cat("    - offtarget_scatter.pdf\n")
cat("    - risk_distribution.pdf\n")
cat("\n")
cat("  Data:\n")
cat("    - position_classification.csv\n")
cat("    - offtargets_classified.csv\n")
cat("    - position_summary.csv\n")
cat("\n")

cat("Key Findings (Test Data):\n")
cat("  - HLA anchors: positions", paste(which(df4_positions$hla_critical), collapse=", "), "\n")
cat("  - Antibody epitope: positions", paste(which(df4_positions$antibody_critical), collapse=", "), "\n")
cat("  - High-risk off-targets:", sum(offtargets_classified$risk == "High"), "\n")
cat("  - Medium-risk off-targets:", sum(offtargets_classified$risk == "Medium"), "\n")
cat("  - Low-risk off-targets:", sum(offtargets_classified$risk == "Low"), "\n")
cat("\n")

cat("This demonstrates the workflow with synthetic data.\n")
cat("Next step: Replace test data with your actual data files!\n\n")

################################################################################
# END OF TEST
################################################################################
