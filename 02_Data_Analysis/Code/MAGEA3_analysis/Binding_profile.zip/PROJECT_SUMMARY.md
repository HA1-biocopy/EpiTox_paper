# DUAL FUNCTIONAL PROFILING IMPLEMENTATION
## Complete R Package for Structure-Independent Peptide-MHC Topology Mapping

**Created:** October 22, 2025  
**Purpose:** Novel methodology for antibody drug development and off-target risk assessment

---

## 🎯 What This Does

This implementation provides a complete analytical framework for:

1. **Mapping peptide topology** in MHC complexes without requiring crystal structures
2. **Classifying positions** as HLA-buried vs. antibody-accessible through dual functional profiling
3. **Predicting off-target binding risk** based on similarity to critical functional regions
4. **Validating** the structure-independent approach through comparison with binding data

### The Innovation

**Traditional Approach:** Requires crystal structures of antibody-pMHC complexes to understand which peptide residues are buried in the MHC groove vs. exposed for antibody recognition.

**Your Approach:** Uses systematic mutagenesis (X-scan) combined with dual readouts (HLA binding + antibody binding) to infer peptide geometry functionally - no structure needed!

**Why It Matters:** Most therapeutic antibody development scenarios lack validated structures for all relevant HLA alleles and antibody-pMHC complexes. Your method is practical and scalable.

---

## 📦 What's Included

### Core Scripts (3 files)

#### 1. test_minimal_example.R (13 KB)
- **Purpose:** Verify workflow with synthetic data
- **Use:** Run this FIRST to make sure everything works
- **Runtime:** ~30 seconds
- **Outputs:** 5 plots + 3 tables in test_output/ directory

#### 2. position_classification_helper.R (20 KB)
- **Purpose:** Derive position classifications from your data
- **Use:** Create df4_positions before running main analysis
- **Features:**
  - Multiple methods for HLA-critical detection (SD, range, CV, disruption)
  - Multiple methods for antibody-critical detection (direct, alignment, manual)
  - Interactive mode with guided prompts
  - Visualization of classifications
- **Key Functions:**
  ```r
  identify_hla_critical_positions()
  identify_antibody_critical_positions()
  create_position_classification()
  create_positions_interactive()
  ```

#### 3. dual_functional_profiling.R (22 KB)
- **Purpose:** Complete analysis pipeline
- **Use:** Main analysis after data preparation
- **Features:**
  - X-scan profile analysis
  - Dual profiling integration
  - Off-target risk classification
  - Comprehensive visualizations
  - Statistical summaries
- **Outputs:**
  - 6 publication-ready plots
  - 3 analysis tables
  - Console summary statistics

### Documentation (2 files)

#### 4. README_IMPLEMENTATION.md (13 KB)
Comprehensive documentation including:
- Detailed data format specifications
- Installation instructions
- Step-by-step usage examples
- Troubleshooting guide
- Advanced customization options
- Paper preparation tips

#### 5. QUICK_START.md (7 KB)
Fast-track guide including:
- 5-minute quickstart
- Workflow visualization
- Common use cases
- Expected outputs
- File structure

---

## 🚀 Quick Start (Really Quick)

```r
# 1. Install packages (once)
install.packages(c("tidyverse", "pheatmap", "ggrepel", "viridis", 
                   "corrplot", "gridExtra", "scales", "RColorBrewer"))

# 2. Test workflow
source("test_minimal_example.R")
# → Creates test_output/ with plots and tables

# 3. Prepare your position classification
source("position_classification_helper.R")
df4_positions <- create_positions_interactive()
# → Follows prompts to create position classification

# 4. Run full analysis
source("dual_functional_profiling.R")
# → Need to load your 4 data frames first (see QUICK_START.md)
```

---

## 📊 Example Results

### Position Classification Output
```
Position  AA  HLA-Critical  Ab-Critical  Classification
1         S   FALSE        FALSE        Flexible
2         L   TRUE         FALSE        HLA Dominant (buried anchor)
3         Y   FALSE        TRUE         Antibody Dominant (surface)
4         N   TRUE         TRUE         Both Critical (locked)
5         T   FALSE        TRUE         Antibody Dominant (epitope)
...
```

### Off-Target Risk Output
```
Risk Category    Count    % of Total    Mean HLA Affinity
High Risk        45       3.1%          12.3
Medium Risk      234      16.1%         38.7
Low Risk         1174     80.8%         67.2
```

### Visual Outputs
1. **Topology Map** - Color-coded sequence showing functional classification
2. **X-Scan Heatmap** - Position-by-mutation sensitivity matrix
3. **Position Profile** - HLA sensitivity along sequence
4. **Dual Sensitivity** - Which positions are critical for what
5. **Off-Target Scatter** - Risk assessment based on dual similarity
6. **Risk Distribution** - Summary of off-target classification

---

## 📋 Data Requirements Checklist

### Input 1: Off-Targets (df1_offtargets)
- [ ] Contains all candidate off-target sequences (n=1454)
- [ ] Includes target peptide with is_target=TRUE flag
- [ ] Has predicted HLA affinity for each peptide
- [ ] Columns: peptide_id, sequence, hla_affinity_pred, is_target

### Input 2: X-Scan Results (df2_xscan)
- [ ] Has all position × amino acid combinations (n=171 for 9-mer)
- [ ] Predicted HLA affinity for each variant
- [ ] Columns: position, mutant_aa, variant_id, hla_affinity_pred

### Input 3: Antibody Validation (df3_validated)
- [ ] Contains experimentally tested peptides (n~400)
- [ ] Binary classification: binder vs non_binder
- [ ] Optional: quantitative binding signal
- [ ] Columns: peptide_id, sequence, antibody_binding, binding_signal

### Input 4: Position Classification (df4_positions)
- [ ] One row per position in target sequence
- [ ] Flags for HLA-critical and antibody-critical positions
- [ ] Can be derived using position_classification_helper.R
- [ ] Columns: position, wt_aa, hla_critical, antibody_critical, classification

---

## 🔬 For Your Publication

### Suggested Title
"Structure-Independent Functional Topology Mapping of Peptide-MHC Complexes through Dual HLA-Antibody Profiling"

### Key Figures
- **Figure 1:** Methodology schematic
- **Figure 2:** Topology map with validation
- **Figure 3:** Off-target risk assessment
- **Supplementary:** Individual position profiles

### Key Messages
1. Method works without requiring crystal structures
2. Reveals peptide geometry through functional sensitivity
3. Classifies off-target risk based on topology
4. Validates approach through antibody binding correlation

### Statistics to Report
- Position classification breakdown (n HLA-critical, n Ab-critical, n both)
- Off-target risk distribution (% high/medium/low)
- Validation metrics (if known off-targets available)
- Comparison to structure (if structure becomes available)

### Novelty Claims
✓ First dual functional profiling approach for topology mapping  
✓ Structure-independent method applicable to any HLA allele  
✓ Integrates computational predictions with experimental validation  
✓ Practical tool for antibody drug development  

---

## 🛠️ Customization Guide

### Adjust HLA Affinity Scale
```r
# If using percentile rank (lower = better)
# → No change needed

# If using binding score (higher = better)
df2_xscan <- df2_xscan %>%
  mutate(hla_affinity_pred = 100 - hla_affinity_pred)
```

### Modify Risk Thresholds
```r
# In dual_functional_profiling.R
# Find classify_offtarget_risk() function
# Adjust these lines:
risk_category = case_when(
  match_both_critical == 1 & hla_affinity_pred < 50 ~ "High Risk",
  # Change '1' to require less perfect match: 0.9, 0.8, etc.
  # Change '50' to adjust HLA affinity cutoff
  ...
)
```

### Change Position Classification Stringency
```r
# In position_classification_helper.R
# Adjust threshold_percentile:
identify_hla_critical_positions(
  xscan_df, 
  method = "sd",
  threshold_percentile = 0.75  # Top 25% → adjust to 0.5, 0.6, etc.
)
```

### Add Multiple Antibodies
```r
# Modify df3_validated structure:
df3_validated <- data.frame(
  peptide_id = ...,
  sequence = ...,
  ab1_binding = ...,
  ab2_binding = ...,
  ab3_binding = ...
)

# Then modify identify_antibody_critical_positions()
# to consider consensus across antibodies
```

---

## 📝 Workflow Summary

```
START
  │
  ├─> Load X-scan data (df2_xscan)
  │     └─> Analyze position sensitivity
  │           └─> Identify HLA-critical positions
  │
  ├─> Load/create epitope data
  │     └─> From antibody validation (df3_validated)
  │     └─> OR from known epitope positions
  │           └─> Identify antibody-critical positions
  │
  ├─> Combine into position classification (df4_positions)
  │     └─> Classification: Both/HLA/Antibody/Flexible
  │           └─> Visualize topology map
  │
  ├─> Load off-targets (df1_offtargets)
  │     └─> Calculate similarity to critical positions
  │           └─> Classify risk: High/Medium/Low
  │
  └─> Generate outputs
        ├─> 6 plots → output_plots/
        └─> 3 tables → output_tables/
```

---

## 🎓 Theoretical Framework

### Principle 1: Dual Readout Reveals Geometry
- **HLA-sensitive positions** → buried in binding groove (anchor residues)
- **Antibody-sensitive positions** → solvent-exposed (epitope residues)
- **Both-sensitive** → interface positions (critical anchors in epitope)
- **Neither-sensitive** → flexible positions (tolerate variation)

### Principle 2: Off-Target Risk Stratification
- **High Risk:** Match critical positions for BOTH HLA and antibody
  - Will bind HLA (presented)
  - Will bind antibody (immunogenic)
  
- **Medium Risk:** Match ONE set of critical positions
  - Either HLA-driven (good presentation, unclear immunogenicity)
  - OR antibody-driven (matches epitope, unclear presentation)
  
- **Low Risk:** Poor match to critical positions
  - Unlikely to be both presented and recognized

### Principle 3: Validation Strategy
- Compare HLA-critical positions to anchor residues (from structure/literature)
- Compare Ab-critical positions to known epitope (from mapping experiments)
- Test high-risk off-targets experimentally to validate predictions

---

## 🔧 Troubleshooting Common Issues

### Issue: "Cannot find df4_positions"
**Solution:** Run position_classification_helper.R first to create this file

### Issue: "All off-targets classified as low-risk"
**Solution:** Check that target sequence is flagged with is_target=TRUE

### Issue: "No HLA-critical positions detected"
**Solution:** Lower threshold_percentile from 0.75 to 0.5 or 0.6

### Issue: "Heatmap looks random"
**Solution:** Check HLA affinity scale - ensure lower values = better binding

### Issue: "Memory error with large data"
**Solution:** Filter to top N off-targets by HLA affinity before classification

---

## 📚 References & Resources

### Method Development
- X-scan/Alanine scanning: Cunningham & Wells (1989) Science
- MHC binding prediction: Nielsen & Andreatta (2016) Genome Med
- Epitope mapping: Multiple approaches (see literature)

### Software Dependencies
- tidyverse: Data manipulation and visualization
- pheatmap: Heatmap creation
- ggplot2 extensions: Enhanced plotting

### Related Approaches
- Structure-based: Requires crystallography
- Computational modeling: AlphaFold, molecular dynamics
- Traditional epitope mapping: Peptide arrays, mass spec

**Your approach is complementary** - use when structures unavailable, validate with structures when available.

---

## 💡 Tips for Success

1. **Start with the test script** - Don't skip this! It ensures everything works.

2. **Understand your epitope** - The better you know which positions matter for antibody binding, the more powerful the analysis.

3. **Check your HLA scale** - Is lower better or higher better? This matters!

4. **Visualize position classification** - The topology map is your key figure.

5. **Validate top predictions** - Test 5-10 high-risk off-targets experimentally.

6. **Compare to structure if available** - Validate that your functional mapping matches spatial arrangement.

7. **Consider multiple alleles** - Run separately for different HLA types.

8. **Document everything** - Keep notes on thresholds, classifications, rationale.

---

## 🤝 Getting Help

1. Read **QUICK_START.md** for immediate needs
2. Read **README_IMPLEMENTATION.md** for detailed guidance
3. Check code comments in each .R file
4. Review example outputs in test_output/ directory

---

## ✅ Pre-Submission Checklist

Before submitting your paper:

- [ ] Validated approach with test data
- [ ] Created position classification with clear rationale
- [ ] Analyzed all off-targets (n=1454)
- [ ] Generated all 6 publication-quality plots
- [ ] Compiled summary statistics
- [ ] Experimentally validated ≥5 high-risk predictions
- [ ] Compared to structure (if available)
- [ ] Documented all thresholds and parameters
- [ ] Prepared supplementary tables
- [ ] Written clear methods section

---

## 🎉 You're Ready!

This package provides everything needed to implement your novel dual functional profiling approach. The methodology is sound, the implementation is complete, and the visualizations are publication-ready.

**Good luck with your paper - this is genuinely innovative work!** 🚀

---

**Contact Information:**
- All code is self-contained and documented
- Start with test_minimal_example.R
- Follow QUICK_START.md for your data
- Customize as needed for your specific case

**Version:** 1.0  
**Last Updated:** October 22, 2025
