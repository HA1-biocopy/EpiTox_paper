################################################################################
# DUAL FUNCTIONAL PROFILING: HLA-ANTIBODY TOPOLOGY MAPPING
# Structure-independent peptide-MHC conformation analysis
################################################################################

# Load required libraries
library(tidyverse)
library(pheatmap)
library(ggrepel)
library(viridis)
library(corrplot)
library(gridExtra)
library(scales)
library(RColorBrewer)

# Set theme for all plots
theme_set(theme_bw(base_size = 12))

################################################################################
# 1. DATA LOADING AND PREPARATION
################################################################################

# Load your data frames
# Replace these with your actual data loading commands
# Example structure shown below:

# df1_offtargets <- read.csv("offtargets.csv")  # n=1454
# df2_xscan <- read.csv("xscan_hla.csv")         # n=171
# df3_validated <- read.csv("antibody_validated.csv")  # n~400
# df4_positions <- read.csv("position_classification.csv")

# For demonstration, let's create example data structures
# REPLACE THIS SECTION WITH YOUR ACTUAL DATA

create_example_data <- function() {
  # Example target sequence (replace with yours)
  target_seq <- "MLAGKSLVLL"
  target_length <- nchar(target_seq)
  
  # 1. Off-targets data frame
  df1_offtargets <- tibble(
    peptide_id = paste0("OT_", 1:1454),
    sequence = replicate(1454, paste(sample(c("A","C","D","E","F","G","H","I","K","L",
                                               "M","N","P","Q","R","S","T","V","W","Y"), 
                                             target_length, replace=TRUE), collapse="")),
    hla_affinity_pred = runif(1454, 0, 100),  # predicted affinity (lower = better)
    is_target = c(TRUE, rep(FALSE, 1453))
  )
  
  # 2. X-scan data (19 amino acids × target length)
  amino_acids <- c("A","C","D","E","F","G","H","I","K","L",
                   "M","N","P","Q","R","S","T","V","W","Y")
  df2_xscan <- expand_grid(
    position = 1:target_length,
    mutant_aa = amino_acids[amino_acids != "A"]  # exclude one as wt
  ) %>%
    mutate(
      variant_id = paste0("P", position, mutant_aa),
      hla_affinity_pred = runif(n(), 0, 100)
    )
  
  # 3. Validated antibody binding data
  df3_validated <- tibble(
    peptide_id = paste0("VAL_", 1:400),
    sequence = replicate(400, paste(sample(c("A","C","D","E","F","G","H","I","K","L",
                                              "M","N","P","Q","R","S","T","V","W","Y"), 
                                            target_length, replace=TRUE), collapse="")),
    antibody_binding = sample(c("binder", "non_binder"), 400, replace=TRUE, prob=c(0.3, 0.7)),
    binding_signal = ifelse(antibody_binding == "binder", 
                           rnorm(400, 80, 15), rnorm(400, 20, 10))
  )
  
  # 4. Target position classification (from your X-scan analysis)
  df4_positions <- tibble(
    position = 1:target_length,
    wt_aa = strsplit(target_seq, "")[[1]],
    hla_critical = sample(c(TRUE, FALSE), target_length, replace=TRUE, prob=c(0.3, 0.7)),
    antibody_critical = sample(c(TRUE, FALSE), target_length, replace=TRUE, prob=c(0.3, 0.7))
  ) %>%
    mutate(
      classification = case_when(
        hla_critical & antibody_critical ~ "Both Critical",
        hla_critical & !antibody_critical ~ "HLA Dominant",
        !hla_critical & antibody_critical ~ "Antibody Dominant",
        TRUE ~ "Flexible"
      )
    )
  
  return(list(
    offtargets = df1_offtargets,
    xscan = df2_xscan,
    validated = df3_validated,
    positions = df4_positions
  ))
}

# Load or create data
data_list <- create_example_data()  # REPLACE with your actual data loading

################################################################################
# 2. X-SCAN ANALYSIS: POSITION-SPECIFIC SENSITIVITY
################################################################################

analyze_xscan_profile <- function(xscan_df, positions_df, 
                                  affinity_threshold = 50) {
  
  # Calculate position-specific metrics
  position_summary <- xscan_df %>%
    group_by(position) %>%
    summarise(
      mean_affinity = mean(hla_affinity_pred, na.rm=TRUE),
      sd_affinity = sd(hla_affinity_pred, na.rm=TRUE),
      cv_affinity = sd_affinity / mean_affinity,  # coefficient of variation
      min_affinity = min(hla_affinity_pred, na.rm=TRUE),
      max_affinity = max(hla_affinity_pred, na.rm=TRUE),
      range_affinity = max_affinity - min_affinity,
      n_strong_binders = sum(hla_affinity_pred < affinity_threshold, na.rm=TRUE),
      pct_tolerated = n_strong_binders / n() * 100
    ) %>%
    left_join(positions_df, by = "position")
  
  return(position_summary)
}

position_profile <- analyze_xscan_profile(data_list$xscan, data_list$positions)

################################################################################
# 3. DUAL PROFILING INTEGRATION
################################################################################

create_dual_profile_matrix <- function(xscan_df, validated_df, positions_df) {
  
  # For each position, calculate:
  # 1. HLA sensitivity score (from X-scan)
  # 2. Antibody sensitivity score (from validated data - this requires mapping)
  
  # HLA sensitivity: how much does mutation affect HLA binding?
  hla_sensitivity <- xscan_df %>%
    group_by(position) %>%
    summarise(
      hla_sensitivity = sd(hla_affinity_pred, na.rm=TRUE),
      .groups = 'drop'
    )
  
  # Note: Antibody sensitivity calculation depends on your data structure
  # This is a placeholder - you'll need to adapt based on how your validated
  # data maps to positions
  
  # Create dual profile
  dual_profile <- positions_df %>%
    left_join(hla_sensitivity, by = "position") %>%
    mutate(
      # Normalize scores
      hla_score_norm = scale(hla_sensitivity)[,1],
      # Classification based on dual criteria
      topology_class = case_when(
        hla_score_norm > 1 ~ "HLA-Critical (Buried)",
        hla_score_norm < -0.5 ~ "Surface-Exposed",
        TRUE ~ "Intermediate"
      )
    )
  
  return(dual_profile)
}

dual_profile <- create_dual_profile_matrix(data_list$xscan, 
                                          data_list$validated, 
                                          data_list$positions)

################################################################################
# 4. OFF-TARGET CLASSIFICATION
################################################################################

classify_offtarget_risk <- function(offtarget_df, dual_profile_df, 
                                    target_sequence) {
  
  # Extract critical positions
  hla_critical_pos <- dual_profile_df %>%
    filter(hla_critical) %>%
    pull(position)
  
  ab_critical_pos <- dual_profile_df %>%
    filter(antibody_critical) %>%
    pull(position)
  
  both_critical_pos <- dual_profile_df %>%
    filter(classification == "Both Critical") %>%
    pull(position)
  
  # Calculate similarity scores for each off-target
  offtarget_classified <- offtarget_df %>%
    rowwise() %>%
    mutate(
      # Calculate positional matches
      match_hla_critical = calculate_position_match(sequence, target_sequence, hla_critical_pos),
      match_ab_critical = calculate_position_match(sequence, target_sequence, ab_critical_pos),
      match_both_critical = calculate_position_match(sequence, target_sequence, both_critical_pos),
      
      # Risk classification
      risk_category = case_when(
        match_both_critical == 1 & hla_affinity_pred < 50 ~ "High Risk",
        match_hla_critical > 0.8 | match_ab_critical > 0.8 ~ "Medium Risk",
        TRUE ~ "Low Risk"
      ),
      
      # Predicted binding mode
      binding_mode = case_when(
        match_hla_critical > match_ab_critical ~ "HLA-driven",
        match_ab_critical > match_hla_critical ~ "Epitope-driven",
        TRUE ~ "Balanced"
      )
    ) %>%
    ungroup()
  
  return(offtarget_classified)
}

# Helper function to calculate position-specific matches
calculate_position_match <- function(seq1, seq2, positions) {
  if(length(positions) == 0) return(0)
  
  seq1_split <- strsplit(seq1, "")[[1]]
  seq2_split <- strsplit(seq2, "")[[1]]
  
  # Handle different lengths
  min_len <- min(length(seq1_split), length(seq2_split))
  positions <- positions[positions <= min_len]
  
  if(length(positions) == 0) return(0)
  
  matches <- sum(seq1_split[positions] == seq2_split[positions])
  return(matches / length(positions))
}

# Get target sequence
target_seq <- data_list$offtargets %>%
  filter(is_target) %>%
  pull(sequence) %>%
  first()

offtargets_classified <- classify_offtarget_risk(
  data_list$offtargets, 
  dual_profile, 
  target_seq
)

################################################################################
# 5. VISUALIZATION FUNCTIONS
################################################################################

# 5.1 Dual Profile Heatmap
plot_dual_profile_heatmap <- function(dual_profile_df, xscan_df) {
  
  # Create matrix for heatmap
  heatmap_matrix <- xscan_df %>%
    select(position, mutant_aa, hla_affinity_pred) %>%
    pivot_wider(names_from = position, values_from = hla_affinity_pred) %>%
    column_to_rownames("mutant_aa") %>%
    as.matrix()
  
  # Annotation for positions
  annotation_col <- dual_profile_df %>%
    select(position, classification) %>%
    column_to_rownames("position")
  
  # Colors
  ann_colors <- list(
    classification = c(
      "Both Critical" = "#d73027",
      "HLA Dominant" = "#fc8d59",
      "Antibody Dominant" = "#91bfdb",
      "Flexible" = "#4575b4"
    )
  )
  
  p <- pheatmap(
    heatmap_matrix,
    cluster_rows = TRUE,
    cluster_cols = FALSE,
    annotation_col = annotation_col,
    annotation_colors = ann_colors,
    color = colorRampPalette(rev(brewer.pal(n = 7, name = "RdYlBu")))(100),
    main = "X-Scan HLA Affinity Profile\nwith Functional Classification",
    fontsize = 10,
    annotation_names_col = TRUE,
    show_colnames = TRUE
  )
  
  return(p)
}

# 5.2 Position Profile Plot
plot_position_profile <- function(position_profile_df) {
  
  p <- ggplot(position_profile_df, aes(x = position)) +
    geom_line(aes(y = mean_affinity, color = "Mean HLA Affinity"), size = 1) +
    geom_ribbon(aes(ymin = mean_affinity - sd_affinity, 
                    ymax = mean_affinity + sd_affinity),
                alpha = 0.2) +
    geom_point(aes(y = mean_affinity, fill = classification), 
               size = 4, shape = 21, color = "black", stroke = 1) +
    scale_fill_manual(
      values = c(
        "Both Critical" = "#d73027",
        "HLA Dominant" = "#fc8d59",
        "Antibody Dominant" = "#91bfdb",
        "Flexible" = "#4575b4"
      )
    ) +
    scale_color_manual(values = c("Mean HLA Affinity" = "black")) +
    labs(
      title = "Position-Specific HLA Binding Profile",
      subtitle = "Error bars represent standard deviation across all substitutions",
      x = "Peptide Position",
      y = "Predicted HLA Affinity",
      fill = "Functional Classification",
      color = ""
    ) +
    theme_bw(base_size = 12) +
    theme(
      legend.position = "bottom",
      legend.box = "vertical",
      panel.grid.minor = element_blank()
    )
  
  return(p)
}

# 5.3 Dual Sensitivity Scatter Plot
plot_dual_sensitivity <- function(dual_profile_df) {
  
  p <- ggplot(dual_profile_df, aes(x = hla_score_norm, y = position)) +
    geom_segment(aes(xend = 0, yend = position, color = classification),
                 size = 1.5, alpha = 0.7) +
    geom_point(aes(fill = classification), 
               size = 5, shape = 21, color = "black", stroke = 1) +
    geom_vline(xintercept = c(-0.5, 1), linetype = "dashed", alpha = 0.5) +
    scale_fill_manual(
      values = c(
        "Both Critical" = "#d73027",
        "HLA Dominant" = "#fc8d59",
        "Antibody Dominant" = "#91bfdb",
        "Flexible" = "#4575b4"
      )
    ) +
    scale_color_manual(
      values = c(
        "Both Critical" = "#d73027",
        "HLA Dominant" = "#fc8d59",
        "Antibody Dominant" = "#91bfdb",
        "Flexible" = "#4575b4"
      )
    ) +
    labs(
      title = "HLA Sensitivity by Position",
      subtitle = "Positions to the right are more sensitive to mutation (HLA-critical/buried)",
      x = "Normalized HLA Sensitivity Score",
      y = "Position",
      fill = "Classification",
      color = "Classification"
    ) +
    theme_bw(base_size = 12) +
    theme(
      legend.position = "right",
      panel.grid.minor = element_blank()
    )
  
  return(p)
}

# 5.4 Off-Target Risk Distribution
plot_offtarget_risk <- function(offtargets_df) {
  
  p1 <- ggplot(offtargets_df, aes(x = risk_category, fill = risk_category)) +
    geom_bar() +
    geom_text(stat = 'count', aes(label = after_stat(count)), 
              vjust = -0.5, size = 4) +
    scale_fill_manual(
      values = c(
        "High Risk" = "#d73027",
        "Medium Risk" = "#fee090",
        "Low Risk" = "#4575b4"
      )
    ) +
    labs(
      title = "Off-Target Risk Distribution",
      x = "Risk Category",
      y = "Number of Off-Targets"
    ) +
    theme_bw(base_size = 12) +
    theme(legend.position = "none")
  
  p2 <- ggplot(offtargets_df, aes(x = hla_affinity_pred, fill = risk_category)) +
    geom_histogram(bins = 30, alpha = 0.7, position = "identity") +
    scale_fill_manual(
      values = c(
        "High Risk" = "#d73027",
        "Medium Risk" = "#fee090",
        "Low Risk" = "#4575b4"
      )
    ) +
    labs(
      title = "HLA Affinity Distribution by Risk",
      x = "Predicted HLA Affinity",
      y = "Count",
      fill = "Risk Category"
    ) +
    theme_bw(base_size = 12)
  
  return(list(p1 = p1, p2 = p2))
}

# 5.5 Off-Target Similarity Scatter
plot_offtarget_similarity <- function(offtargets_df) {
  
  # Filter to top candidates
  top_offtargets <- offtargets_df %>%
    filter(risk_category %in% c("High Risk", "Medium Risk")) %>%
    arrange(desc(match_both_critical), hla_affinity_pred) %>%
    head(50)
  
  p <- ggplot(offtargets_df, aes(x = match_hla_critical, y = match_ab_critical)) +
    geom_point(aes(color = risk_category, size = hla_affinity_pred),
               alpha = 0.6) +
    geom_point(data = top_offtargets, 
               aes(color = risk_category), 
               size = 4, shape = 21, stroke = 1.5, fill = NA) +
    scale_color_manual(
      values = c(
        "High Risk" = "#d73027",
        "Medium Risk" = "#fee090",
        "Low Risk" = "#4575b4"
      )
    ) +
    scale_size_continuous(trans = "reverse", range = c(1, 5)) +
    labs(
      title = "Off-Target Dual Similarity Profile",
      subtitle = "Outlined points are top 50 candidates",
      x = "Match to HLA-Critical Positions",
      y = "Match to Antibody-Critical Positions",
      color = "Risk Category",
      size = "HLA Affinity\n(lower=better)"
    ) +
    theme_bw(base_size = 12) +
    theme(legend.position = "right")
  
  return(p)
}

# 5.6 Topology Map
plot_topology_map <- function(dual_profile_df) {
  
  p <- ggplot(dual_profile_df, aes(x = position, y = 1)) +
    geom_tile(aes(fill = classification), color = "black", size = 1) +
    geom_text(aes(label = wt_aa), size = 6, fontface = "bold") +
    scale_fill_manual(
      values = c(
        "Both Critical" = "#d73027",
        "HLA Dominant" = "#fc8d59",
        "Antibody Dominant" = "#91bfdb",
        "Flexible" = "#4575b4"
      )
    ) +
    scale_x_continuous(breaks = dual_profile_df$position) +
    labs(
      title = "Functional Topology Map",
      subtitle = "Red: Locked positions | Orange: HLA-buried | Blue: Surface-exposed | Dark Blue: Flexible",
      x = "Position",
      fill = "Classification"
    ) +
    theme_minimal(base_size = 12) +
    theme(
      axis.text.y = element_blank(),
      axis.title.y = element_blank(),
      panel.grid = element_blank(),
      legend.position = "bottom"
    )
  
  return(p)
}

################################################################################
# 6. GENERATE ALL PLOTS
################################################################################

generate_all_visualizations <- function(data_list, position_profile, 
                                        dual_profile, offtargets_classified) {
  
  cat("Generating visualizations...\n")
  
  # Create output directory
  if(!dir.exists("output_plots")) dir.create("output_plots")
  
  # 1. Dual Profile Heatmap
  cat("  - Dual profile heatmap...\n")
  pdf("output_plots/1_dual_profile_heatmap.pdf", width = 12, height = 8)
  plot_dual_profile_heatmap(dual_profile, data_list$xscan)
  dev.off()
  
  # 2. Position Profile
  cat("  - Position profile...\n")
  p2 <- plot_position_profile(position_profile)
  ggsave("output_plots/2_position_profile.pdf", p2, width = 12, height = 6)
  
  # 3. Dual Sensitivity
  cat("  - Dual sensitivity...\n")
  p3 <- plot_dual_sensitivity(dual_profile)
  ggsave("output_plots/3_dual_sensitivity.pdf", p3, width = 10, height = 8)
  
  # 4. Off-Target Risk
  cat("  - Off-target risk distribution...\n")
  p4_list <- plot_offtarget_risk(offtargets_classified)
  pdf("output_plots/4_offtarget_risk.pdf", width = 14, height = 6)
  grid.arrange(p4_list$p1, p4_list$p2, ncol = 2)
  dev.off()
  
  # 5. Off-Target Similarity
  cat("  - Off-target similarity scatter...\n")
  p5 <- plot_offtarget_similarity(offtargets_classified)
  ggsave("output_plots/5_offtarget_similarity.pdf", p5, width = 10, height = 8)
  
  # 6. Topology Map
  cat("  - Topology map...\n")
  p6 <- plot_topology_map(dual_profile)
  ggsave("output_plots/6_topology_map.pdf", p6, width = 12, height = 4)
  
  cat("All plots saved to output_plots/ directory\n")
}

################################################################################
# 7. SUMMARY STATISTICS AND EXPORT
################################################################################

generate_summary_statistics <- function(position_profile, dual_profile, 
                                       offtargets_classified) {
  
  cat("\n" ,"="*80, "\n")
  cat("DUAL FUNCTIONAL PROFILING ANALYSIS SUMMARY\n")
  cat("="*80, "\n\n")
  
  # Position classification summary
  cat("POSITION CLASSIFICATION:\n")
  print(table(dual_profile$classification))
  cat("\n")
  
  # Critical positions
  cat("CRITICAL POSITIONS:\n")
  cat("  HLA-Critical:", sum(dual_profile$hla_critical), "positions\n")
  cat("  Antibody-Critical:", sum(dual_profile$antibody_critical), "positions\n")
  cat("  Both Critical:", sum(dual_profile$classification == "Both Critical"), "positions\n")
  cat("\n")
  
  # Off-target risk summary
  cat("OFF-TARGET RISK ASSESSMENT:\n")
  risk_summary <- offtargets_classified %>%
    group_by(risk_category) %>%
    summarise(
      count = n(),
      pct = n() / nrow(offtargets_classified) * 100,
      mean_hla_affinity = mean(hla_affinity_pred, na.rm=TRUE)
    )
  print(risk_summary)
  cat("\n")
  
  # High risk off-targets
  high_risk <- offtargets_classified %>%
    filter(risk_category == "High Risk") %>%
    arrange(hla_affinity_pred) %>%
    head(10)
  
  cat("TOP 10 HIGH-RISK OFF-TARGETS:\n")
  print(high_risk %>% select(peptide_id, sequence, hla_affinity_pred, 
                             match_both_critical, binding_mode))
  
  cat("\n", "="*80, "\n\n")
  
  # Export summary tables
  if(!dir.exists("output_tables")) dir.create("output_tables")
  
  write_csv(dual_profile, "output_tables/dual_profile_summary.csv")
  write_csv(offtargets_classified, "output_tables/offtargets_classified.csv")
  write_csv(position_profile, "output_tables/position_profile.csv")
  
  cat("Summary tables exported to output_tables/ directory\n")
}

################################################################################
# 8. MAIN EXECUTION
################################################################################

main <- function() {
  
  cat("\n")
  cat("################################################################################\n")
  cat("# DUAL FUNCTIONAL PROFILING ANALYSIS\n")
  cat("# Structure-Independent Peptide-MHC Topology Mapping\n")
  cat("################################################################################\n\n")
  
  # Run analysis
  cat("Step 1: Analyzing X-scan profile...\n")
  position_profile <- analyze_xscan_profile(data_list$xscan, data_list$positions)
  
  cat("Step 2: Creating dual profile matrix...\n")
  dual_profile <- create_dual_profile_matrix(data_list$xscan, 
                                             data_list$validated, 
                                             data_list$positions)
  
  cat("Step 3: Classifying off-targets...\n")
  target_seq <- data_list$offtargets %>%
    filter(is_target) %>%
    pull(sequence) %>%
    first()
  
  offtargets_classified <- classify_offtarget_risk(data_list$offtargets, 
                                                   dual_profile, 
                                                   target_seq)
  
  cat("Step 4: Generating visualizations...\n")
  generate_all_visualizations(data_list, position_profile, 
                             dual_profile, offtargets_classified)
  
  cat("Step 5: Generating summary statistics...\n")
  generate_summary_statistics(position_profile, dual_profile, 
                             offtargets_classified)
  
  cat("\n✓ Analysis complete!\n\n")
  
  # Return results
  return(list(
    position_profile = position_profile,
    dual_profile = dual_profile,
    offtargets_classified = offtargets_classified
  ))
}

# Run the analysis
results <- main()

################################################################################
# END OF SCRIPT
################################################################################
