# Dual Functional Profiling Analysis - Implementation Guide

## Overview
This R implementation performs structure-independent peptide-MHC topology mapping through dual HLA-antibody profiling. It integrates X-scan mutagenesis data with antibody validation results to classify positions and predict off-target risks.

---

## Data Requirements

### 1. Off-Targets Data Frame (n = 1454)
**Required columns:**
```r
- peptide_id          # Unique identifier
- sequence            # Peptide amino acid sequence
- hla_affinity_pred   # Predicted HLA binding affinity (numeric)
- is_target           # Logical flag for target peptide (TRUE/FALSE)
```

**Example:**
```r
df1_offtargets <- read.csv("your_offtargets.csv")
```

### 2. X-Scan Data Frame (n = 171, or 19 × sequence_length)
**Required columns:**
```r
- position            # Position in target sequence (1-indexed)
- mutant_aa           # Amino acid substitution
- variant_id          # Identifier like "P3A" (position 3 to Alanine)
- hla_affinity_pred   # Predicted HLA affinity for this variant
```

**Example:**
```r
df2_xscan <- read.csv("your_xscan_results.csv")
```

**Expected format:**
```
position  mutant_aa  variant_id  hla_affinity_pred
1         A          P1A         45.2
1         C          P1C         78.9
1         D          P1D         23.4
...
```

### 3. Validated Antibody Binding Data (n ~ 400)
**Required columns:**
```r
- peptide_id          # Unique identifier
- sequence            # Peptide amino acid sequence
- antibody_binding    # "binder" or "non_binder"
- binding_signal      # Numeric binding signal (optional but recommended)
```

**Example:**
```r
df3_validated <- read.csv("your_antibody_validation.csv")
```

### 4. Position Classification Data
**Required columns:**
```r
- position            # Position in target sequence
- wt_aa               # Wild-type amino acid at this position
- hla_critical        # Logical: Is this position HLA-critical?
- antibody_critical   # Logical: Is this position antibody-critical?
```

**Example:**
```r
df4_positions <- read.csv("your_position_classification.csv")
```

**How to generate this if you don't have it:**
```r
# From your X-scan analysis
df4_positions <- df2_xscan %>%
  group_by(position) %>%
  summarise(
    # Mark as HLA-critical if mutations strongly affect binding
    hla_critical = sd(hla_affinity_pred) > threshold_value,
    # Get wild-type AA from target sequence
    wt_aa = target_sequence_vector[position]
  ) %>%
  left_join(antibody_criticality_data, by = "position")
```

---

## Installation

### Required R Packages
```r
install.packages(c(
  "tidyverse",      # Data manipulation and ggplot2
  "pheatmap",       # Heatmap visualization
  "ggrepel",        # Label positioning
  "viridis",        # Color scales
  "corrplot",       # Correlation plots
  "gridExtra",      # Multiple plots
  "scales",         # Scale functions
  "RColorBrewer"    # Color palettes
))
```

---

## Quick Start

### Step 1: Load Your Data
Replace the `create_example_data()` section in the script with your actual data:

```r
# Load your four data frames
df1_offtargets <- read.csv("offtargets.csv", stringsAsFactors = FALSE)
df2_xscan <- read.csv("xscan_hla.csv", stringsAsFactors = FALSE)
df3_validated <- read.csv("antibody_validated.csv", stringsAsFactors = FALSE)
df4_positions <- read.csv("position_classification.csv", stringsAsFactors = FALSE)

# Create data list
data_list <- list(
  offtargets = df1_offtargets,
  xscan = df2_xscan,
  validated = df3_validated,
  positions = df4_positions
)
```

### Step 2: Verify Data Structure
```r
# Check your data
str(data_list$offtargets)
str(data_list$xscan)
str(data_list$validated)
str(data_list$positions)

# Verify target is present
data_list$offtargets %>% filter(is_target) %>% nrow()  # Should be 1
```

### Step 3: Run the Analysis
```r
source("dual_functional_profiling.R")
```

This will:
1. Analyze X-scan profiles
2. Create dual functional profiles
3. Classify off-targets by risk
4. Generate all visualizations
5. Export summary tables

---

## Key Customization Points

### 1. Affinity Thresholds
Adjust based on your HLA binding prediction scale:

```r
# In analyze_xscan_profile()
affinity_threshold = 50  # Change to match your scale
```

**Common scales:**
- IC50 (nM): Lower = better binding, threshold ~500 nM
- Percentile rank: Lower = better, threshold ~2%
- Affinity score: Higher = better, threshold varies

### 2. Risk Classification Criteria
Modify in `classify_offtarget_risk()`:

```r
risk_category = case_when(
  match_both_critical == 1 & hla_affinity_pred < 50 ~ "High Risk",
  match_hla_critical > 0.8 | match_ab_critical > 0.8 ~ "Medium Risk",
  TRUE ~ "Low Risk"
)
```

### 3. Position Classification Logic
If you need to derive position classifications from scratch:

```r
# Add to the script before analyze_xscan_profile()
df4_positions <- df2_xscan %>%
  group_by(position) %>%
  summarise(
    wt_aa = target_seq_vector[position],
    # HLA-critical: high variability means position is sensitive
    hla_sensitive_score = sd(hla_affinity_pred, na.rm = TRUE),
    hla_critical = hla_sensitive_score > quantile(hla_sensitive_score, 0.75)
  ) %>%
  left_join(
    # Antibody-critical: from your validation data
    # This needs your specific mapping logic
    your_antibody_position_analysis,
    by = "position"
  )
```

---

## Interpreting Your Position Classification (df4_positions)

### How to Determine if a Position is HLA-Critical

From your X-scan data:

```r
# Calculate sensitivity for each position
position_sensitivity <- df2_xscan %>%
  group_by(position) %>%
  summarise(
    # Method 1: Standard deviation (variability)
    sd_affinity = sd(hla_affinity_pred),
    
    # Method 2: Range (max - min)
    range_affinity = max(hla_affinity_pred) - min(hla_affinity_pred),
    
    # Method 3: Coefficient of variation
    cv_affinity = sd(hla_affinity_pred) / mean(hla_affinity_pred),
    
    # Method 4: Number of disruptive mutations
    n_disruptive = sum(hla_affinity_pred > threshold)
  )

# Classify as HLA-critical if high sensitivity
position_sensitivity <- position_sensitivity %>%
  mutate(
    hla_critical = sd_affinity > quantile(sd_affinity, 0.75) |
                   n_disruptive < quantile(n_disruptive, 0.25)
  )
```

### How to Determine if a Position is Antibody-Critical

This depends on your validation data structure. Here are common approaches:

**Approach 1: If you have position-specific antibody binding data**
```r
# If your validated data includes position mutations
antibody_position_data <- df3_validated %>%
  # Extract position from peptide comparison with target
  mutate(
    mutated_position = identify_mutation_position(sequence, target_sequence),
    binding_numeric = ifelse(antibody_binding == "binder", 1, 0)
  ) %>%
  group_by(mutated_position) %>%
  summarise(
    binding_rate = mean(binding_numeric),
    antibody_critical = binding_rate < 0.3  # Loss of binding
  ) %>%
  rename(position = mutated_position)
```

**Approach 2: If you only have general binder/non-binder classification**
```r
# You may need to infer antibody-critical positions from:
# 1. Literature (known epitopes)
# 2. Structural data (if available)
# 3. Computational epitope prediction
# 4. Alanine scan on target with antibody

# Example: Mark positions 3, 5, 7 as antibody-critical based on epitope mapping
df4_positions <- df4_positions %>%
  mutate(
    antibody_critical = position %in% c(3, 5, 7)  # YOUR positions here
  )
```

**Approach 3: Use correlation with validated data**
```r
# For each position, create variants and check against validated set
# This is more complex and requires sequence alignment

calculate_antibody_impact <- function(position, xscan_df, validated_df) {
  # Get all variants at this position
  variants_at_pos <- xscan_df %>%
    filter(position == !!position)
  
  # Create sequences for these variants
  # Compare with validated binders/non-binders
  # Return impact score
}

df4_positions <- df4_positions %>%
  rowwise() %>%
  mutate(
    antibody_impact = calculate_antibody_impact(position, df2_xscan, df3_validated),
    antibody_critical = antibody_impact > threshold
  )
```

---

## Output Files

### Plots (in `output_plots/` directory)
1. **1_dual_profile_heatmap.pdf** - X-scan heatmap with position annotations
2. **2_position_profile.pdf** - Position-by-position HLA sensitivity
3. **3_dual_sensitivity.pdf** - HLA sensitivity scores by position
4. **4_offtarget_risk.pdf** - Off-target risk distribution
5. **5_offtarget_similarity.pdf** - Dual similarity scatter plot
6. **6_topology_map.pdf** - Functional topology visualization

### Tables (in `output_tables/` directory)
1. **dual_profile_summary.csv** - Position classifications and scores
2. **offtargets_classified.csv** - All off-targets with risk assessment
3. **position_profile.csv** - Detailed position statistics

---

## Common Issues and Solutions

### Issue 1: "Position mismatch in X-scan data"
**Problem:** Your X-scan might not cover all positions
**Solution:**
```r
# Check coverage
table(df2_xscan$position)

# Fill missing positions with NA
all_positions <- 1:target_length
df2_xscan <- complete(df2_xscan, position = all_positions, mutant_aa)
```

### Issue 2: "Target sequence not found"
**Problem:** Target flag is missing or incorrect
**Solution:**
```r
# Manually specify target
target_seq <- "MLAGKSLVLL"  # Your actual target sequence

# Or fix the flag
df1_offtargets <- df1_offtargets %>%
  mutate(is_target = sequence == target_seq)
```

### Issue 3: "Different affinity scales"
**Problem:** HLA predictions use different scales
**Solution:**
```r
# Normalize to 0-100 scale
df2_xscan <- df2_xscan %>%
  mutate(
    hla_affinity_pred = rescale(hla_affinity_pred, to = c(0, 100))
  )
```

---

## Advanced Customization

### Adding Additional Metrics

You can extend the analysis with:

1. **Sequence conservation scores**
```r
# Add conservation data
df4_positions <- df4_positions %>%
  left_join(conservation_scores, by = "position")
```

2. **Structural features (if available)**
```r
# Add secondary structure, accessibility, etc.
df4_positions <- df4_positions %>%
  left_join(structural_features, by = "position")
```

3. **Multiple antibody validation**
```r
# If you have multiple antibodies
df3_validated_multi <- df3_validated %>%
  pivot_wider(
    names_from = antibody_id,
    values_from = antibody_binding,
    names_prefix = "ab_"
  )
```

---

## Example Workflow with Real Data

```r
# 1. Load libraries
library(tidyverse)
library(pheatmap)

# 2. Load your data
df1_offtargets <- read_csv("your_data/offtargets_predicted.csv")
df2_xscan <- read_csv("your_data/xscan_mutations_hla.csv")
df3_validated <- read_csv("your_data/antibody_validation_results.csv")

# 3. Create position classification
target_seq <- "MLAGKSLVLL"
target_length <- nchar(target_seq)

df4_positions <- df2_xscan %>%
  group_by(position) %>%
  summarise(
    wt_aa = str_sub(target_seq, position, position),
    sd_affinity = sd(hla_affinity_pred, na.rm = TRUE),
    mean_affinity = mean(hla_affinity_pred, na.rm = TRUE)
  ) %>%
  mutate(
    # Positions with high SD are HLA-critical
    hla_critical = sd_affinity > quantile(sd_affinity, 0.75, na.rm = TRUE),
    # Define antibody-critical from your epitope mapping
    antibody_critical = position %in% c(3, 5, 7, 9),  # YOUR EPITOPE
    # Combined classification
    classification = case_when(
      hla_critical & antibody_critical ~ "Both Critical",
      hla_critical ~ "HLA Dominant",
      antibody_critical ~ "Antibody Dominant",
      TRUE ~ "Flexible"
    )
  )

# 4. Create data list
data_list <- list(
  offtargets = df1_offtargets,
  xscan = df2_xscan,
  validated = df3_validated,
  positions = df4_positions
)

# 5. Source and run the analysis script
source("dual_functional_profiling.R")

# 6. The main() function runs automatically
# Or run step-by-step for more control
```

---

## For Your Paper

### Key Figures to Include

1. **Figure 1: Topology Map** (`6_topology_map.pdf`)
   - Shows the functional classification of each position
   - Color-coded by HLA-buried vs. surface-exposed

2. **Figure 2: Dual Profile Heatmap** (`1_dual_profile_heatmap.pdf`)
   - X-scan results with classification overlay
   - Demonstrates position-specific sensitivity

3. **Figure 3: Off-Target Risk Analysis** (`5_offtarget_similarity.pdf`)
   - Shows how off-targets cluster by similarity to critical regions
   - Validates the classification system

### Key Statistics to Report

From the summary output:
- Number of HLA-critical positions
- Number of antibody-critical positions
- Number of "Both Critical" positions (locked)
- Percentage of off-targets in each risk category
- Validation of predictions (if you have known off-targets)

---

## Contact & Support

If you need help adapting this script to your specific data:
1. Check that your column names match the requirements
2. Verify your affinity scale and adjust thresholds
3. Ensure your target sequence is correctly flagged
4. Review the position classification logic for your use case

---

## Citation

If you use this framework in your publication:
```
Structure-independent functional topology mapping of peptide-MHC complexes 
through dual HLA-antibody profiling analysis
```
