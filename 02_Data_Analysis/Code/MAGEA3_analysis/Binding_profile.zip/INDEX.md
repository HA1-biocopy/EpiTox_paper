# 📁 DUAL FUNCTIONAL PROFILING - FILE INDEX

## 🎯 START HERE

**New to this project?** → Open [QUICK_START.md](QUICK_START.md)  
**Need details?** → Open [README_IMPLEMENTATION.md](README_IMPLEMENTATION.md)  
**Want overview?** → Open [PROJECT_SUMMARY.md](PROJECT_SUMMARY.md)

---

## 📂 All Files

### 🟢 Executable Scripts (Run These)

#### [test_minimal_example.R](test_minimal_example.R) - TEST FIRST!
- **What:** Complete working example with synthetic data
- **When:** Run this FIRST to verify everything works
- **Time:** 30 seconds
- **Output:** 5 plots + 3 tables in test_output/

#### [position_classification_helper.R](position_classification_helper.R)
- **What:** Tools to create position classification from your data
- **When:** Before running main analysis
- **Use:**
  ```r
  source("position_classification_helper.R")
  df4_positions <- create_positions_interactive()  # Guided mode
  ```

#### [dual_functional_profiling.R](dual_functional_profiling.R)
- **What:** Main analysis pipeline
- **When:** After preparing your 4 data frames
- **Use:**
  ```r
  source("dual_functional_profiling.R")
  results <- main()  # Runs complete analysis
  ```

### 📘 Documentation (Read These)

#### [QUICK_START.md](QUICK_START.md) - ⭐ Read This First
- 5-minute quickstart guide
- Workflow diagram
- Common use cases
- Expected outputs
- **Best for:** Getting started quickly

#### [README_IMPLEMENTATION.md](README_IMPLEMENTATION.md) - ⭐ Complete Reference
- Detailed data format specs
- Installation instructions
- Usage examples
- Troubleshooting
- Advanced options
- **Best for:** Detailed implementation guidance

#### [PROJECT_SUMMARY.md](PROJECT_SUMMARY.md) - ⭐ Overview
- Complete project documentation
- Theoretical framework
- Publication tips
- Customization guide
- **Best for:** Understanding the full project

#### INDEX.md (This File)
- Navigation guide
- Quick reference
- **Best for:** Finding what you need

---

## 🚦 Recommended Workflow

### Phase 1: Verification (5 minutes)
```r
source("test_minimal_example.R")
```
✓ Installs packages  
✓ Runs complete analysis with test data  
✓ Creates all outputs  
✓ Verifies everything works  

### Phase 2: Data Preparation (15-30 minutes)
```r
source("position_classification_helper.R")

# Option A: Interactive mode (easiest)
df4_positions <- create_positions_interactive()

# Option B: Programmatic (more control)
df4_positions <- create_position_classification(
  target_sequence = "YOURSEQ",
  xscan_df = your_xscan_data,
  known_epitope_positions = c(3, 5, 7)
)

write_csv(df4_positions, "df4_positions.csv")
```

### Phase 3: Main Analysis (2-5 minutes)
```r
source("dual_functional_profiling.R")

# Prepare data
data_list <- list(
  offtargets = read_csv("your_offtargets.csv"),
  xscan = read_csv("your_xscan.csv"),
  validated = read_csv("your_validation.csv"),
  positions = read_csv("df4_positions.csv")
)

# Run
results <- main()
```

### Phase 4: Review Outputs
Check these directories:
- `output_plots/` - 6 publication-ready figures
- `output_tables/` - 3 analysis tables
- Console output - Summary statistics

---

## 📊 Expected Outputs

### From test_minimal_example.R
```
test_output/
├── topology_map.pdf
├── xscan_heatmap.pdf
├── position_sensitivity.pdf
├── offtarget_scatter.pdf
├── risk_distribution.pdf
├── position_classification.csv
├── offtargets_classified.csv
└── position_summary.csv
```

### From dual_functional_profiling.R
```
output_plots/
├── 1_dual_profile_heatmap.pdf
├── 2_position_profile.pdf
├── 3_dual_sensitivity.pdf
├── 4_offtarget_risk.pdf
├── 5_offtarget_similarity.pdf
└── 6_topology_map.pdf

output_tables/
├── dual_profile_summary.csv
├── offtargets_classified.csv
└── position_profile.csv
```

---

## 🎯 Quick Reference

### Data Requirements

| File | Rows | Key Columns | Purpose |
|------|------|-------------|---------|
| df1_offtargets | 1454 | peptide_id, sequence, hla_affinity_pred, is_target | All candidates |
| df2_xscan | 171 | position, mutant_aa, hla_affinity_pred | Sensitivity data |
| df3_validated | ~400 | peptide_id, sequence, antibody_binding | Experimental validation |
| df4_positions | 9 | position, wt_aa, hla_critical, antibody_critical | Position classes |

### Key Functions

| Function | Script | Purpose |
|----------|--------|---------|
| `create_positions_interactive()` | helper | Guided position classification |
| `create_position_classification()` | helper | Programmatic position classification |
| `identify_hla_critical_positions()` | helper | Find HLA-sensitive positions |
| `identify_antibody_critical_positions()` | helper | Find antibody-sensitive positions |
| `main()` | profiling | Run complete analysis |
| `analyze_xscan_profile()` | profiling | Analyze X-scan data |
| `classify_offtarget_risk()` | profiling | Risk stratification |

### Key Parameters to Adjust

| Parameter | Location | Default | Adjust To |
|-----------|----------|---------|-----------|
| `affinity_threshold` | analyze_xscan_profile() | 50 | Your HLA scale |
| `threshold_percentile` | identify_hla_critical() | 0.75 | 0.5-0.9 |
| `match_both_critical` | classify_offtarget_risk() | 1.0 | 0.8-1.0 |
| `hla_affinity_pred` cutoff | classify_offtarget_risk() | 50 | Your scale |

---

## 🆘 Common Questions

**Q: Which file do I run first?**  
A: `test_minimal_example.R` - Always test with synthetic data first!

**Q: I don't have df4_positions - what do I do?**  
A: Run `position_classification_helper.R` to create it from your X-scan and epitope data.

**Q: Can I use this without antibody validation data?**  
A: Yes! Use known epitope positions instead. See position_classification_helper.R

**Q: How do I know if my HLA scale is correct?**  
A: Check if lower values = better binding. If not, use `mutate(hla_affinity_pred = 100 - hla_affinity_pred)`

**Q: All my off-targets are low-risk - why?**  
A: Verify target sequence is flagged, check position numbering, adjust thresholds.

**Q: Which plots should I use in my paper?**  
A: Core figures: topology_map, dual_profile_heatmap, offtarget_similarity

**Q: Can I analyze multiple HLA alleles?**  
A: Yes - run separately for each allele, then compare classifications.

---

## 📝 Citation Information

### For Your Methods Section

```
Position classifications were derived through dual functional profiling, 
analyzing position-specific sensitivity to both HLA binding (from X-scan 
mutagenesis) and antibody recognition (from experimental validation). 
Positions were classified as HLA-critical (high variability in X-scan, 
indicating anchor residues buried in the MHC groove), antibody-critical 
(required for antibody binding, indicating surface-exposed epitope residues), 
both critical (interface positions), or flexible (tolerant to substitution). 
Off-target peptides were risk-stratified based on sequence similarity to 
critical positions in both functional contexts.
```

### Novel Contribution Statement

```
This work introduces structure-independent functional topology mapping, 
enabling inference of peptide conformation in MHC complexes through dual 
profiling of HLA binding and antibody recognition sensitivity. Unlike 
traditional approaches requiring crystal structures, this method is 
applicable to any HLA allele and therapeutic antibody combination, 
providing practical risk assessment for antibody drug development.
```

---

## ✅ Pre-Analysis Checklist

Before running your analysis:

- [ ] Installed all required R packages
- [ ] Ran test_minimal_example.R successfully
- [ ] Have all 4 required data files
- [ ] Verified column names match requirements
- [ ] Checked HLA affinity scale (lower = better?)
- [ ] Know your antibody epitope positions OR have validation data
- [ ] Verified target sequence is flagged in off-targets file
- [ ] Created df4_positions using helper script
- [ ] Reviewed expected outputs in test_output/

---

## 🔄 Update Log

**Version 1.0** (October 22, 2025)
- Initial release
- Complete implementation of dual functional profiling
- Full documentation suite
- Test data and examples

---

## 📞 Need Help?

1. **Quick question?** → Check [QUICK_START.md](QUICK_START.md)
2. **Data format issue?** → See [README_IMPLEMENTATION.md](README_IMPLEMENTATION.md) Section 2
3. **Code not working?** → Run [test_minimal_example.R](test_minimal_example.R) first
4. **Conceptual question?** → Read [PROJECT_SUMMARY.md](PROJECT_SUMMARY.md) Theory section
5. **Still stuck?** → Check code comments in the R scripts

---

## 🎓 Learning Path

### Beginner (Never used R or this method)
1. Read QUICK_START.md
2. Run test_minimal_example.R
3. Follow interactive mode in position_classification_helper.R
4. Review outputs in test_output/

### Intermediate (Know R, new to this method)
1. Read PROJECT_SUMMARY.md for theory
2. Run test_minimal_example.R
3. Adapt position_classification_helper.R examples
4. Run dual_functional_profiling.R with your data

### Advanced (Ready to customize)
1. Review all documentation
2. Modify classification thresholds in helper script
3. Extend dual_functional_profiling.R for your needs
4. Add custom analyses or visualizations

---

## 🎉 You're All Set!

Everything you need is here:
- ✅ Working code with test data
- ✅ Comprehensive documentation
- ✅ Step-by-step guides
- ✅ Publication-ready outputs

**Start with QUICK_START.md and you'll be running analyses in 5 minutes!**

Good luck! 🚀
