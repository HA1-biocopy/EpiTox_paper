# QUICK START GUIDE
## Dual Functional Profiling for Antibody Off-Target Analysis

---

## The Approach in One Picture

```
YOUR DATA                          ANALYSIS                           OUTPUTS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

1) Off-targets (1454)              ┌─────────────────────┐          
   - sequences                     │  DUAL PROFILING     │          📊 6 Plots
   - predicted HLA affinity  ─────>│                     │────────> 📊 Position topology
                                    │  Maps each position │          📊 Risk distribution
2) X-scan (171 = 19×9)             │  as:                │          📊 Similarity scatter
   - position mutations      ─────>│  • HLA-buried       │
   - HLA affinity changes           │  • Surface-exposed  │          📄 3 Tables
                                    │  • Both/Neither     │────────> 📄 Position classes
3) Antibody validation (~400) ────>│                     │          📄 Off-target risks
   - binders vs non-binders         │  Then classifies    │          📄 Summary stats
                                    │  off-target risk    │
4) Known epitope positions   ─────>│                     │          
   - from mapping/literature        └─────────────────────┘          🎯 High-risk targets
                                                                         for validation

NOVELTY: Infers peptide geometry in MHC groove WITHOUT structure
         by comparing HLA vs antibody sensitivity at each position
```

---

## What You Have

Four R scripts for implementing your novel structure-independent topology mapping approach:

1. **test_minimal_example.R** - Start here! Test the workflow with synthetic data
2. **position_classification_helper.R** - Derive position classifications from your data
3. **dual_functional_profiling.R** - Complete analysis pipeline
4. **README_IMPLEMENTATION.md** - Detailed documentation

---

## Getting Started (5 minutes)

### Step 1: Test the Workflow
```r
# Open R or RStudio
# Install packages (first time only)
install.packages(c("tidyverse", "pheatmap", "ggrepel", "viridis", 
                   "corrplot", "gridExtra", "scales", "RColorBrewer"))

# Run test with synthetic data
source("test_minimal_example.R")

# Check outputs in test_output/ folder
```

This creates 5 plots and 3 data tables demonstrating the complete workflow.

### Step 2: Prepare Your Position Classification

If you **know your antibody epitope positions**:
```r
source("position_classification_helper.R")

# Replace these with your values
target_seq <- "YOURSEQUENCE"
epitope_positions <- c(3, 5, 7)  # Your epitope

# Load your X-scan data
xscan_data <- read_csv("your_xscan_file.csv")

# Create classification
df4_positions <- create_position_classification(
  target_sequence = target_seq,
  xscan_df = xscan_data,
  hla_method = "sd",
  ab_method = "manual",
  known_epitope_positions = epitope_positions
)

# Save it
write_csv(df4_positions, "df4_positions.csv")
```

If you **have antibody validation data** to infer epitope:
```r
source("position_classification_helper.R")

# Interactive mode - follows prompts
df4_positions <- create_positions_interactive()
```

### Step 3: Run Full Analysis

```r
source("dual_functional_profiling.R")

# Load your 4 data frames
data_list <- list(
  offtargets = read_csv("your_offtargets.csv"),
  xscan = read_csv("your_xscan.csv"),
  validated = read_csv("your_validation.csv"),
  positions = read_csv("df4_positions.csv")  # From Step 2
)

# Run analysis
results <- main()

# Check output_plots/ and output_tables/ folders
```

---

## Your Data Format Requirements

### 1. Off-targets file (df1_offtargets)
```
peptide_id,sequence,hla_affinity_pred,is_target
OT_001,SLYNTVATL,23.4,FALSE
TARGET,SLYNTVATL,5.2,TRUE
...
```

### 2. X-scan file (df2_xscan)
```
position,mutant_aa,variant_id,hla_affinity_pred
1,A,P1A,45.2
1,C,P1C,78.9
2,A,P2A,12.3
...
```

### 3. Validation file (df3_validated)
```
peptide_id,sequence,antibody_binding,binding_signal
VAL_001,SLYNTVATL,binder,85.3
VAL_002,ALYNTVATL,non_binder,12.1
...
```

### 4. Position classification (df4_positions)
```
position,wt_aa,hla_critical,antibody_critical,classification
1,S,FALSE,FALSE,Flexible
2,L,TRUE,FALSE,HLA Dominant
3,Y,FALSE,TRUE,Antibody Dominant
4,N,TRUE,TRUE,Both Critical
...
```

---

## Expected Outputs

### Visualizations (6 plots)
1. **Dual profile heatmap** - X-scan with functional annotations
2. **Position profile** - HLA sensitivity along the sequence
3. **Dual sensitivity** - Which positions are critical
4. **Off-target risk distribution** - High/Medium/Low risk counts
5. **Off-target similarity scatter** - Dual matching profile
6. **Topology map** - Color-coded position classifications

### Data Tables (3 files)
1. **dual_profile_summary.csv** - Position-level statistics
2. **offtargets_classified.csv** - All off-targets with risk scores
3. **position_profile.csv** - Detailed X-scan summaries

---

## For Your Paper

### Main Figure Suggestion
```
Figure: Structure-Independent Functional Topology Mapping

Panel A: Topology map showing classification of each position
Panel B: X-scan heatmap demonstrating differential sensitivity  
Panel C: Off-target risk distribution based on topology
Panel D: Example high-risk off-targets with similarity scores
```

### Key Statistics to Report
- N positions HLA-critical (buried in groove)
- N positions antibody-critical (surface-exposed)
- N positions both critical (locked/anchor+epitope)
- % off-targets classified as high-risk
- Validation metrics if known off-targets available

### Novelty Statement
"We developed a structure-independent method for mapping peptide topology in MHC complexes by systematically profiling position-specific sensitivity to both HLA binding and antibody recognition. Unlike traditional structure-based approaches, our dual functional profiling reveals which residues are buried (HLA-critical) versus surface-exposed (antibody-accessible) without requiring crystallography or computational modeling."

---

## Troubleshooting

**Problem: Script fails at loading data**
- Check column names match requirements
- Verify CSV format (no Excel artifacts)
- Check for NA values in critical columns

**Problem: No HLA-critical positions detected**
- Lower threshold_percentile (try 0.5 instead of 0.75)
- Check affinity scale (higher = better or lower = better?)
- Verify X-scan covers all positions

**Problem: All off-targets classified as low-risk**
- Check if target sequence is in off-targets dataframe
- Verify position numbers match sequence length
- Adjust risk thresholds in classify_offtarget_risk()

---

## Customization Tips

### Change HLA affinity scale
```r
# If your scale is IC50 (lower = better)
# No change needed - script assumes lower = better

# If your scale is score (higher = better)
df2_xscan <- df2_xscan %>%
  mutate(hla_affinity_pred = 100 - hla_affinity_pred)
```

### Adjust risk thresholds
```r
# In dual_functional_profiling.R, find:
risk_category = case_when(
  match_both_critical == 1 & hla_affinity_pred < 50 ~ "High Risk",
  # Adjust the '1' and '50' as needed
  ...
)
```

### Focus on specific positions
```r
# Only analyze positions 1-8 (if C-terminal is flexible)
df2_xscan <- df2_xscan %>% filter(position <= 8)
df4_positions <- df4_positions %>% filter(position <= 8)
```

---

## Next Steps After Analysis

1. **Validate predictions**
   - Test top high-risk off-targets experimentally
   - Confirm antibody binding profile matches predictions

2. **Refine classification**
   - Update df4_positions based on validation
   - Re-run analysis with refined positions

3. **Compare to structure (if available)**
   - Validate that HLA-critical = buried residues
   - Check antibody-critical = surface-exposed

4. **Extend analysis**
   - Multiple HLA alleles
   - Multiple antibodies
   - Different binding conditions

---

## File Structure After Running

```
your_project/
├── test_minimal_example.R
├── position_classification_helper.R
├── dual_functional_profiling.R
├── README_IMPLEMENTATION.md
├── QUICK_START.md (this file)
│
├── test_output/              # From Step 1
│   ├── topology_map.pdf
│   ├── xscan_heatmap.pdf
│   └── ...
│
├── output_plots/             # From Step 3
│   ├── 1_dual_profile_heatmap.pdf
│   ├── 2_position_profile.pdf
│   └── ...
│
└── output_tables/            # From Step 3
    ├── dual_profile_summary.csv
    ├── offtargets_classified.csv
    └── position_profile.csv
```

---

## Support

Read the **README_IMPLEMENTATION.md** for:
- Detailed data format specifications
- Advanced customization options
- Common issues and solutions
- Additional analysis options

Good luck with your paper! This is genuinely novel work. 🎯
