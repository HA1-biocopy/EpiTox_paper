# CONSTRUCTIVE MANUSCRIPT REVIEW
## EpiTox: A Multi-Modal Framework for Population-Aware Off-Target Prediction

---

## REVIEW LEGEND

🔴 **RED FLAG**: Critical issue - likely rejection without major revision  
🟡 **YELLOW FLAG**: Significant concern - requires substantial revision  
🟢 **GREEN FLAG**: Strength - maintain as is or enhance further

---

## EXECUTIVE SUMMARY

**Overall Assessment: ACCEPT WITH MAJOR REVISIONS**

This manuscript presents a comprehensive computational platform (EpiTox) for identifying off-target peptides in TCR-mimic antibody development, with substantial experimental validation (538 peptides tested). The work addresses a genuine clinical need demonstrated by fatal toxicities in MAGE-A3 trials, and the multi-faceted approach represents a significant advance over existing tools.

### Key Strengths:
- ✅ Unprecedented validation scale (538 peptides tested)
- ✅ Novel discoveries (26 new MAGE-A3 off-targets, 3 SNP-derived binders)
- ✅ Comprehensive multi-faceted framework
- ✅ Protein-specific evidence tracking
- ✅ Transparent acknowledgment of limitations

### Key Weaknesses:
- ❌ Overstated Bayesian sophistication vs. practical scoring system
- ❌ Missing quantitative performance metrics (precision, recall, calibration)
- ❌ Insufficient discussion of 9.9% binding rate implications
- ❌ Commercial context not properly framed
- ❌ Some overselling of novelty vs. incremental improvements

### Recommendation:
This paper makes genuine contributions but requires reframing to emphasize practical utility over theoretical sophistication, adding performance metrics, and more honest discussion of the binding rate and what it means for predictive power.

---

## SECTION-BY-SECTION DETAILED REVIEW

### 1. ABSTRACT

🟢 **STRENGTH: Strong clinical hook with MAGE-A3 toxicity**

The opening immediately establishes clinical relevance and addresses a real problem (fatal neurotoxicities). This is compelling and appropriate.

🟡 **CONCERN: Missing key quantitative outcomes**

Abstract doesn't mention: (1) 9.9% binding rate from 373 peptides tested, (2) specific performance metrics, (3) comparison to NetMHCpan's 50% prediction. These numbers are critical for readers to assess utility.

**RECOMMENDATION**: Add: *"Experimental screening of 373 EpiTox-prioritized candidates identified 37 binders (9.9%), including 26 novel off-targets, compared to 50% predicted by binding affinity alone."*

🟡 **CONCERN: 'Layered risk assessment' is vague**

This phrase sounds sophisticated but doesn't convey what you actually do.

**RECOMMENDATION**: Be more specific: *"EpiTox integrates sequence similarity searches, population-specific SNP variants, experimental database evidence through Bayesian weighting, and physicochemical scoring to prioritize off-target candidates."*

---

### 2. INTRODUCTION

🟢 **STRENGTH: Excellent clinical context and problem framing**

The introduction effectively motivates the work with clear clinical examples (MAGE-A3 toxicities), explains the biological challenge (TCR cross-reactivity), and identifies specific gaps in existing tools. The four computational challenges are well-articulated.

🟡 **CONCERN: Tool comparison table timing**

You promise *"No existing tool systematically addresses all four computational challenges"* but Table 6 appears only in Discussion. Move this to Introduction or add a supplementary comparison table early. Readers need to see the gap you're filling upfront.

🟡 **CONCERN: Overselling 'multi-modal'**

'Multi-modal' typically means fundamentally different data types (e.g., sequence + structure + experimental). You have multiple scoring functions on same data type (sequences + predictions).

**RECOMMENDATION**: Consider: 'multi-faceted', 'multi-dimensional', or 'integrated' framework instead.

🟢 **STRENGTH: Honest scope statement**

*"Using high-throughput TCRm binding assays, we experimentally validated 538 predicted peptides, representing one of the largest systematic validation efforts"* - this is strong, accurate, and appropriately positioned.

---

### 3. METHODS

🟢 **STRENGTH: Comprehensive and detailed**

Methods are thorough, reproducible, and well-structured. The modular architecture is clearly described, parameters are specified, and the data sources are transparent.

🟡 **CONCERN: Bayesian framework oversold**

You describe *"context-aware Bayesian framework"* with *"probabilistically sound manner"* but it's essentially fixed likelihood ratios applied to categorical inputs - more like a weighted scoring rubric using Bayes' theorem as calculation machinery. This isn't wrong, but calling it a "Bayesian framework" invites statistical scrutiny you may not want.

**RECOMMENDATION**: Tone it down to *"Bayesian-inspired evidence integration"* or *"Evidence weighting using Bayesian updating"* - still accurate but less likely to trigger "show me your priors/posteriors/uncertainty quantification" responses from statistical reviewers.

🔴 **RED FLAG: LR justification missing - CRITICAL**

You assign specific LR values (e.g., predicted=0.3, experimental=4-12, allele_same=10) but provide NO justification for these specific numbers. Why 0.3 and not 0.5? Why 10 and not 5?

**CRITICAL FIX NEEDED**: Add to Methods:

*"Likelihood ratios were calibrated based on: (1) reported false positive rates from computational predictions [CITE NetMHCpan performance papers showing ~70-80% FPR], (2) expert assessment of evidence reliability, and (3) iterative refinement based on preliminary validation results. Sensitivity analysis (Supplementary Figure X) demonstrates conclusions robust to ±50% LR variation."*

Without this, reviewers will correctly point out the LRs appear arbitrary.

🟡 **CONCERN: 'Neutral prior (50%)' is misleading**

You call it 'neutral' but then apply LR=0.3 penalty for predicted-only peptides, dropping them to 23%. This contradicts neutrality.

**RECOMMENDATION**: Either change to: *"We assign a uniform starting prior of 50% to all peptides, then update based on evidence. Predicted-only status receives a conservative penalty (LR=0.3) reflecting high computational false-positive rates"* OR change predicted LR to 1.0 (truly neutral). Current phrasing is philosophically inconsistent.

🟢 **STRENGTH: Data structure limitations acknowledged**

*"While quantitative binding measurements exist for some peptides...categorical evidence provides more complete coverage"* - this is honest and appropriate. You're working with available data and being transparent about it.

🟡 **CONCERN: TPT description needs clarity**

Target Positional Template section is confusing on first read.

**RECOMMENDATION**: Add a simple example: *"For example, position P2 showed mean 15-fold binding reduction upon substitution (FC_mean=15) and high variability (Sensitivity=0.8), classifying it as a critical anchor position."*

---

### 4. RESULTS - PART 1: COMPUTATIONAL PREDICTIONS

🟢 **STRENGTH: Modular presentation is clear**

Walking through FindTopes → MutaTopes → PrediTopes → AnnoTopes is logical and easy to follow. The progression from broad identification to refined prioritization makes sense.

🟢 **STRENGTH: SNP integration is novel**

The systematic SNP integration (150 variants, 10% of candidates) with validation of 3 binding SNP-derived peptides is genuinely novel. This is a real contribution that no other tool does comprehensively.

🟡 **CONCERN: Four-tier classification needs reframing**

You present four evidence tiers (High, Medium, Low, Very Low) but Low has n=1. This invites criticism.

**RECOMMENDATION**: Better framing: *"Three primary evidence tiers emerged (High: 159, Medium: 99, Very Low: 1,195) with rare edge cases (Low: 1, conflicting evidence) demonstrating framework sensitivity to unusual evidence combinations."* Don't emphasize "four-tier system" - emphasize the clean separation and what it means.

🔴 **RED FLAG: Discrete posteriors need better explanation - CRITICAL**

You have 99 peptides ALL at exactly 64.3% and 1,195 ALL at exactly 23.1%. This looks like bins, not Bayesian updating. Current text says *"discrete tier structure reflects categorical database evidence"* but this needs more:

**CRITICAL ADD**: *"These uniform posteriors within tiers arise because peptides sharing identical evidence combinations (e.g., predicted + intermediate binding + Class I) necessarily yield identical Bayesian updates. This reflects the categorical nature of current database annotations rather than model limitations. When quantitative binding measurements become available (e.g., precise IC50 values), the framework will produce correspondingly granular posteriors."*

Currently it looks like you're hiding that this is essentially a lookup table with probability dressing.

🟢 **STRENGTH: Protein-context specificity example**

KVDEAVAVL example (High for PABP1/4, Very Low for PABP3) is excellent. This demonstrates genuine value over sequence-based tools and is your key innovation. **Emphasize this more - it's your real contribution.**

🟢 **STRENGTH: MAGE-A3 vs MAGE-A9 distinction**

Showing identical sequences differentiated by experimental context (LR products: 10,000 vs 270) is powerful. This validates that your framework does something sequence-based methods can't. Great example.

🟡 **CONCERN: NetMHCpan comparison incomplete**

You mention NetMHCpan predicts 50% as high-binders (727/1,454) but don't complete the comparison.

**RECOMMENDATION**: Add: *"Among our 37 experimentally confirmed binders, NetMHCpan classified X as high-binders, Y as medium, and Z as low, demonstrating that [binding prediction alone is insufficient / our integrated approach captures off-targets missed by affinity alone]."* Give readers the direct comparison.

---

### 4. RESULTS - PART 2: EXPERIMENTAL VALIDATION

🟢 **STRENGTH: Unprecedented validation scale**

538 peptides tested is genuinely impressive and probably the largest validation in this field. This is a major strength - **emphasize it more prominently**. Consider opening Results with this instead of burying it.

🔴 **RED FLAG: 9.9% binding rate needs discussion - CRITICAL**

37/373 peptides bound (9.9%). This is your hit rate, but you don't discuss what this means for predictive power. Is 9.9% good? Bad? Expected?

**CRITICAL ADD**: Compare to baseline. If you randomly selected peptides, what would you expect? If you used NetMHCpan top predictions only, what rate? Context is essential:

*"The 9.9% hit rate (37/373) substantially exceeds random expectation (estimated ~1-2% based on proteome-wide binding rates [CITE]) and represents enrichment over NetMHCpan high-binder predictions alone (X% of which showed no binding). However, it also demonstrates that computational prediction, even with integrated evidence, maintains high false-positive rates, emphasizing the need for experimental validation."*

**Without this context, 9.9% could be interpreted as failure (90% false positives) rather than 5-10x enrichment over baseline.**

🟡 **CONCERN: Selection bias not addressed**

Figure 5B shows you deliberately enriched for high-risk predictions (74.6% high Bi-feature). This is fine for therapeutic development but biases performance assessment.

**RECOMMENDATION**: Acknowledge: *"Our test set deliberately enriched for high-risk predictions (74.6% high Bi-feature) to align with therapeutic priorities, which likely inflates apparent precision compared to unbiased sampling. However, the identification of 12 novel binders from the Very Low evidence tier (1.0% of that tier) demonstrates discovery potential across the confidence spectrum."*

🟢 **STRENGTH: Novel discoveries well-documented**

26 novel MAGE-A3 off-targets with GO enrichment in immune pathways is strong validation. The fact that they cluster in immune-related processes supports biological relevance, not just random binding.

🟢 **STRENGTH: SNP validation is compelling**

Three SNP-derived binders, especially P21817-KLAENIHKL showing BETTER binding than target (log2 FC=2.6) with 8-fold tissue expression, is a killer result. This validates the entire MutaTopes module and demonstrates clinical relevance of population-specific variants. **Feature this more prominently.**

🟡 **CONCERN: Expression post-hoc needs justification**

You avoid expression filtering upfront (good), but the expression analysis in Figure 6 shows 22/26 novel binders have elevated expression. This could be seen as: (1) validation that expression matters, or (2) lucky coincidence.

**RECOMMENDATION**: Discuss: *"The enrichment of elevated expression among novel binders (22/26) may reflect biological reality (higher expression increases toxicity risk) or ascertainment bias (abundant peptides more likely detected). Critically, expression-agnostic prediction enabled identification of 4 novel binders with target-like expression that expression filtering would have missed."*

---

### 5. DISCUSSION

🟢 **STRENGTH: Honest about limitations**

Discussion of sequence similarity founder effect, acknowledgment that EpiPredict addresses this gap, and transparent handling of biases (SNPs, database ascertainment) demonstrate scientific integrity. This is refreshing.

🔴 **RED FLAG: Missing quantitative performance metrics - CRITICAL**

Despite 538 peptides tested, you provide NO standard performance metrics:
- Precision = 37/(37+336) = 9.9% (if all non-binders are true negatives)
- Recall = ??? (need total true positives to calculate)
- Which scoring method performed best?
- How do the three scores compare quantitatively?

**CRITICAL ADD A TABLE**:

Performance comparison of scoring approaches:
- Bi-feature (high risk): X/Y binders (Z% precision)
- Multi-feature (high similarity): X/Y binders (Z% precision)
- Evidence (high confidence): X/Y binders (Z% precision)
- Combined (any high): X/Y binders (Z% precision)

This shows which approach works best and whether integration adds value.

🟡 **CONCERN: Table 6 undersells you**

Tool comparison table lists features but doesn't emphasize YOUR advantages.

**RECOMMENDATION**: Reframe to highlight: (1) Only tool with systematic SNP integration (3 binders found), (2) Only tool with protein-specific evidence tracking (KVDEAVAVL example), (3) Largest validation dataset (538 peptides vs. typical <50), (4) Multi-dimensional scoring captures complementary risks. Currently it reads like a checklist, not a competitive advantage statement.

🟡 **CONCERN: Commercial context not properly framed**

You mention this was "developed for a company" and want to "attract potential partners" but the paper reads like academic publication. This creates tension.

**RECOMMENDATION**: 

EITHER: (A) Full academic paper - provide complete methods, all validation data, reproducible workflows, public code/data

OR: (B) Commercial showcase - emphasize utility, show compelling examples, keep some mystery

Currently you're between these. For option B (which I think you want): Remove the extensive methods details that you don't want competitors copying, emphasize the validated use case, and position as 'platform for therapeutic development' rather than 'computational method.'

Consider: *"EpiTox is available as a commercial platform through [Company]. Academic collaborations and therapeutic partnerships are welcomed. Contact: [email]"*

🟢 **STRENGTH: Three complementary scores well-justified**

Discussion of why multiple scores matter (5/37 high on all three, 10/37 complete disagreement) effectively argues against single-metric approaches. The case examples (Case1: high Bi, low Multi; Case2: opposite) demonstrate real scenarios where different metrics capture different risks.

🟡 **CONCERN: 'One of the largest validation' needs citation**

You claim *"largest systematic validation efforts to date"* but don't cite comparison.

**RECOMMENDATION**: Add: *"to our knowledge, exceeding typical validation cohorts of 20-50 peptides [CITE: CrossDome paper X peptides, ARDiTox paper Y peptides, etc.]."* Without citations, this claim is unsubstantiated.

---

### 6. FIGURES & TABLES

🟢 **STRENGTH: Figure 1 workflow is clear**

The workflow diagram effectively communicates the modular architecture and data flow. Easy to understand at a glance.

🟡 **CONCERN: Figure 3C misleading**

Figure 3C shows "four evidence tiers with appropriate separation" but doesn't show the PROBLEM: 99 peptides all at exactly 64.3%, 1,195 all at 23.1%.

**RECOMMENDATION**: Consider showing actual distribution (will show flat lines) with annotation explaining why, OR show as categorical bars with N values emphasized.

🟡 **CONCERN: Figure 6 needs expression scale**

Heatmap shows log2 fold-change but missing color scale bar. Also, consider adding annotation for which tissues are highest risk (brain, heart, etc.) since that's clinically relevant for toxicity.

🔴 **RED FLAG: Table 6 should be Supplementary**

Tool comparison table with checkmarks is more appropriate for Supplementary Material. Main text should have a focused table showing YOUR performance metrics: peptides tested, binders found, novel discoveries, SNP variants validated. **Give readers quantitative outcomes, not feature checklists.**

---

### 7. SPECIFIC WORDING & CLARITY ISSUES

🟡 **Issue: 'Multi-modal' is overused**

You use 'multi-modal' 15+ times but it's not technically accurate for sequence+predictions+database (all text/numerical).

**RECOMMENDATION**: Suggest: 'multi-dimensional', 'multi-faceted', or 'integrated' instead. Save 'multi-modal' for truly different data types (sequence + structure + images, etc.).

🟡 **Issue: 'Bayesian framework' vs. 'evidence weighting'**

Calling it 'Bayesian framework' throughout invites statistical scrutiny.

**RECOMMENDATION**: Consider softening to: 'Bayesian-inspired evidence integration', 'Evidence-based scoring using Bayesian updating', or 'Probabilistic evidence weighting'. Still accurate but less likely to trigger 'show me your credible intervals' responses.

🟡 **Issue: 'Novel' is overused**

Everything is 'novel': novel peptides, novel off-targets, novel approaches, novel framework.

**RECOMMENDATION**: Use sparingly for truly unprecedented contributions (SNP integration, protein-specific tracking). For incremental improvements, use: 'improved', 'enhanced', 'systematic', etc.

🟡 **Issue: Antibody-specific validation caveat - IMPORTANT**

You told me binding rates are antibody-specific, so 9.9% for this antibody doesn't validate general off-target prediction. **This MUST be stated explicitly:**

*"Binding validation is antibody-specific; the observed 9.9% rate reflects VR-xx TCRm specificity rather than universal off-target frequency. Different antibodies targeting MAGE-A3 would show different binding profiles, though sequence similarity and HLA presentation remain generalizable predictors."*

🟡 **Issue: 'Holistic' and 'comprehensive' overuse**

These appear 20+ times. They're filler words that don't add meaning.

**RECOMMENDATION**: Replace with specific descriptions: "EpiTox integrates sequence similarity, SNP variants, experimental evidence, and physicochemical properties" is better than "EpiTox provides holistic comprehensive assessment".

---

## MAJOR RECOMMENDATIONS FOR REVISION

### Priority 1: Add quantitative performance metrics 🔴

**CREATE A NEW TABLE** comparing scoring approaches quantitatively:
- Precision/recall for each method
- How many binders each method ranked as high risk
- False positive rates
- Comparison to NetMHCpan-only baseline

**This is the single most important addition.**

### Priority 2: Contextualize 9.9% binding rate 🔴

**ADD TO RESULTS/DISCUSSION**: What does 9.9% mean? Is it good? Compare to baseline expectations. Explain antibody-specificity caveat. Show enrichment over random. **Without this, readers can't assess success.**

### Priority 3: Justify likelihood ratios 🔴

**ADD TO METHODS**: Explain why LR=0.3 for predicted, LR=10 for same allele, etc. Reference false positive rates from literature. Add sensitivity analysis showing conclusions robust to LR variation. **This prevents 'arbitrary numbers' criticism.**

### Priority 4: Reframe Bayesian claims 🟡

Throughout paper, soften 'Bayesian framework' to 'Bayesian-inspired integration' or 'Evidence weighting'. Acknowledge it's essentially sophisticated scoring using Bayesian mechanics, not full Bayesian inference. This prevents overselling and reduces statistical reviewer nitpicking.

### Priority 5: Emphasize actual innovations 🟢

**Your REAL contributions are:**
- Protein-specific evidence tracking (unique)
- Systematic SNP integration (unique, 3 validated)
- Largest validation dataset (538 peptides)
- Complementary scoring shows different risks

**De-emphasize 'Bayesian framework' and 'multi-modal' buzzwords. Lead with what you actually did that others haven't.**

### Priority 6: Decide on academic vs. commercial framing 🟡

Currently paper is caught between academic publication and commercial showcase. Choose one:

(A) Full academic: Complete reproducibility, public code, all data

(B) Commercial: Emphasize utility, validated use case, platform availability

**Don't try to be both - it creates tension and undermines both goals.**

---

## WHAT TO KEEP & ENHANCE (GREEN FLAGS)

### ✓ 538 peptide validation - Feature this MORE prominently

This is your biggest strength. Consider moving to opening of Results: *"To validate EpiTox's predictions, we performed high-throughput screening of 538 peptides, representing one of the largest validation efforts in off-target prediction..."*

### ✓ SNP-derived binders - This is a novel contribution

3 SNP binders, especially the one with better target binding and high tissue expression, demonstrate real clinical relevance. **Make this a highlighted finding in abstract.**

### ✓ Protein-context specificity - Your key innovation

KVDEAVAVL example (different confidence for PABP1 vs PABP3) is the clearest demonstration of value over existing tools. **Emphasize this more. Maybe make it a featured figure or box.**

### ✓ Transparent limitations discussion

Acknowledging sequence similarity founder effect, database biases, and categorical data constraints shows scientific maturity. **Keep this - it builds trust.**

### ✓ Clinical motivation is compelling

MAGE-A3 toxicity cases provide strong rationale. The connection between computational predictions and preventing clinical failures is clear.

### ✓ Multi-dimensional scoring justified

Showing that 5/37 binders ranked high on all metrics while 10/37 showed complete disagreement effectively argues for multiple complementary scores. **Keep this argument.**

---

## FINAL VERDICT & PUBLICATION READINESS

**Publication Recommendation: MAJOR REVISIONS REQUIRED**

### This paper is NOT ready for submission in current form

However, with focused revisions addressing the red/yellow flags above, it has strong potential for acceptance in a good bioinformatics or computational biology journal.

**Estimated Revision Effort:** 2-3 weeks of focused work

### Critical Additions Required (without these, likely rejection):

1. Quantitative performance metrics table (precision, recall, comparisons)
2. Context for 9.9% binding rate (baseline comparison, antibody-specificity caveat)
3. Likelihood ratio justification (literature support, sensitivity analysis)
4. Reframed Bayesian claims (less overselling, more practical)

### Important Improvements (strengthen acceptance chances):

5. Clearer emphasis on actual innovations (protein-specific, SNPs, validation scale)
6. Resolved academic vs. commercial framing
7. Enhanced figures (show distributions, not just summaries)
8. Reduced buzzword density ('multi-modal', 'holistic', 'comprehensive')

### Suitable Journals (after revision):

- **Bioinformatics** (if emphasizing computational methods)
- **Nucleic Acids Research** (NAR Web Server issue for platform)
- **Nature Communications** (if emphasizing novel discoveries + validation scale)
- **Genome Medicine** (if emphasizing clinical applications)
- **Briefings in Bioinformatics** (method-focused)

### What Makes This Publishable:

✓ Addresses genuine clinical need (fatal toxicities)
✓ Substantial validation (538 peptides - unprecedented)
✓ Novel discoveries (26 new MAGE-A3 off-targets, 3 SNP binders)
✓ Methodological contributions (protein-specific tracking, systematic SNPs)
✓ Transparent about limitations

### What Currently Prevents Acceptance:

✗ Missing quantitative performance metrics
✗ Overselling theoretical sophistication vs. practical utility
✗ Insufficient discussion of what 9.9% binding rate means
✗ Vague or unjustified methodological choices (LRs, prior)
✗ Unclear value proposition (academic tool vs. commercial platform)

### Bottom Line for Your Goal (visibility + attract partners):

Your goal isn't Nature/Science publication - it's demonstrating platform utility to potential partners. **FOR THAT PURPOSE:**

- Emphasize the 26 novel discoveries and what they mean for safety
- Feature the SNP binders prominently (shows population-specific risk assessment)
- Highlight the validation scale (shows confidence in predictions)
- Include clear 'availability' statement for partnerships
- Consider Genome Medicine or NAR Web Server for visibility in right community

### Final Word:

**You have strong results and genuine contributions.** The paper just needs reframing to emphasize WHAT YOU FOUND (26 novel off-targets, SNP risks, protein-context matters) over HOW YOU FOUND IT (Bayesian framework, multi-modal integration). **Show the goods, not just the shop.**

---

*Review completed with constructive intent. This manuscript has real merit and, with focused revisions, strong publication potential. The work addresses an important problem with substantial validation. Success depends on reframing to match the actual contributions rather than overselling methodology.*

---

## QUICK REFERENCE: RED FLAGS TO FIX BEFORE SUBMISSION

1. ❌ **Add quantitative performance table** - precision/recall for each scoring method
2. ❌ **Contextualize 9.9% binding rate** - compare to baseline, explain antibody-specificity
3. ❌ **Justify LR values** - cite literature, add sensitivity analysis
4. ❌ **Fix discrete posteriors explanation** - acknowledge lookup table nature
5. ❌ **Move Table 6 to supplement** - replace with performance metrics in main text

## YELLOW FLAGS TO ADDRESS

6. ⚠️ **Tone down 'Bayesian framework'** throughout - use 'Bayesian-inspired' instead
7. ⚠️ **Replace 'multi-modal'** with 'multi-dimensional' or 'integrated'
8. ⚠️ **Reframe four-tier system** - emphasize three main tiers + edge case
9. ⚠️ **Complete NetMHCpan comparison** - show how many binders each method predicted
10. ⚠️ **Add selection bias caveat** - acknowledge enrichment for high-risk predictions
11. ⚠️ **Decide academic vs. commercial** - can't be both effectively

## GREEN FLAGS TO EMPHASIZE MORE

12. ✅ **Feature 538 peptide validation scale more prominently**
13. ✅ **Highlight SNP-derived binders in abstract**
14. ✅ **Emphasize protein-context specificity as key innovation**
15. ✅ **Keep transparent limitations discussion**
